package ru.pad7.vantavision;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/** Plays a user-selected locally stored track. The app APK contains NO copyrighted recordings. */
public final class MusicService extends Service {
    public static final String PLAY="ru.pad7.vantavision.AUDIO_PLAY";
    public static final String PAUSE="ru.pad7.vantavision.AUDIO_PAUSE";
    public static final String VOL="ru.pad7.vantavision.AUDIO_VOL";
    public static final String STOP="ru.pad7.vantavision.AUDIO_STOP";
    public static final String EXTRA_VOLUME="level";
    public static volatile boolean playing=false;
    public static volatile String lastError="";
    private static final String CHANNEL="vanta_music";
    private static final int ID=211;
    private MediaPlayer player;
    private boolean prepared=false;
    private boolean pendingPlay=false;
    private String loadedUri=null;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i==null)return START_NOT_STICKY;
        String action=i.getAction();
        if(STOP.equals(action)){stopSelf();return START_NOT_STICKY;}
        if(VOL.equals(action)){
            int v=i.getIntExtra(EXTRA_VOLUME,40);
            float f=Math.max(0,Math.min(100,v))/100f;
            if(player!=null)player.setVolume(f,f);
            return START_NOT_STICKY;
        }
        if(PAUSE.equals(action)){
            pendingPlay=false;
            if(player!=null&&prepared&&player.isPlaying())player.pause();playing=false;
            createChannel();startNotification();
            return START_NOT_STICKY;
        }
        if(PLAY.equals(action)){
            try{
                String text=getSharedPreferences("settings",MODE_PRIVATE).getString("musicUri",null);
                if(text==null||text.isEmpty())throw new IllegalStateException("Сначала выбери MP3");
                createChannel();startNotification(); // foreground immediately, even for slow files
                pendingPlay=true;
                if(player!=null && loadedUri!=null && !loadedUri.equals(text)){
                    try{player.stop();}catch(Exception ignored){}
                    player.release();player=null;prepared=false;playing=false;
                }
                if(player==null){
                    loadedUri=text;
                    player=new MediaPlayer();prepared=false;
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    player.setDataSource(this,Uri.parse(text));
                    player.setLooping(true);
                    int v=getSharedPreferences("settings",MODE_PRIVATE).getInt("musicVol",35);
                    float volume=v/100f;player.setVolume(volume,volume);
                    player.setOnErrorListener((mp,what,extra)->{lastError="Аудио: ошибка проигрывателя "+what;playing=false;stopSelf();return true;});
                    player.setOnPreparedListener(mp->{
                        prepared=true;
                        if(pendingPlay){mp.start();playing=true;lastError="";startNotification();}
                    });
                    player.prepareAsync();
                }else if(prepared){player.start();playing=true;lastError="";startNotification();}
            }catch(Exception e){Log.e("Vanta","Music failed",e);lastError="Музыка: "+e.getMessage();playing=false;stopSelf();}
        }

        return START_NOT_STICKY;
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"VANTA • музыка",NotificationManager.IMPORTANCE_LOW));}
    }
    private void startNotification(){
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent p=PendingIntent.getActivity(this,3,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent a=new Intent(this,MusicService.class).setAction(playing?PAUSE:PLAY);
        PendingIntent toggle=PendingIntent.getService(this,4,a,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent end=new Intent(this,MusicService.class).setAction(STOP);
        PendingIntent s=PendingIntent.getService(this,5,end,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification notification=b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("VANTA • музыка")
                .setContentText("Локальный трек • повтор")
                .setContentIntent(p).setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause,"Пауза",toggle)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Выключить",s).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(ID,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(ID,notification);
    }
    @Override public void onDestroy(){
        playing=false;pendingPlay=false;prepared=false;loadedUri=null;
        if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}
        super.onDestroy();
    }
}
