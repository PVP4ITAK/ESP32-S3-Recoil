package ru.pad7.vantavision;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Decorative canvas background; no screenshots, private graphics, or tracking. */
public class NeonBackdrop extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public NeonBackdrop(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h, new int[]{0xFF060913,0xFF0B1424,0xFF060913},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);p.setShader(null);
        p.setShader(new RadialGradient(w*.83f,h*.25f,Math.max(w,h)*.52f,new int[]{0x2637C7C8,0x0817BACB,0x00000000},null,Shader.TileMode.CLAMP));
        c.drawCircle(w*.83f,h*.25f,Math.max(w,h)*.52f,p);p.setShader(null);
        p.setColor(0x1737D2CF);p.setStrokeWidth(1);
        int gap=Math.max(38,(int)(getResources().getDisplayMetrics().density*46));
        for(int x=0;x<w;x+=gap)c.drawLine(x,0,x,h,p);
        for(int y=0;y<h;y+=gap)c.drawLine(0,y,w,y,p);
        float t=(SystemClock.uptimeMillis()%9000L)/9000f;
        p.setColor(0x3449EDE4);p.setStrokeWidth(2);
        float yy=(t*h);c.drawLine(0,yy,w,yy,p);
        p.setColor(Color.WHITE);p.setAlpha(25);
        c.drawCircle(w*.83f,h*.25f,Math.min(w,h)*.16f,p);
        postInvalidateDelayed(95);
    }
}
