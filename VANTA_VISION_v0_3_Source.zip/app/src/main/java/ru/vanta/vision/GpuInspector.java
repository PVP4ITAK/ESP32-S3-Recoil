package ru.vanta.vision;

import android.os.Build;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;

/** Real device capability check. This is diagnostics, not a claim of benchmarked FPS. */
public final class GpuInspector {
    public static final class Result {
        public final String soc, renderer, vendor;
        public final boolean adreno;
        public final int maxTextureSize;
        Result(String soc,String renderer,String vendor,int size){
            this.soc=soc;this.renderer=renderer;this.vendor=vendor;this.maxTextureSize=size;
            this.adreno=renderer.toLowerCase(java.util.Locale.ROOT).contains("adreno");
        }
    }
    private GpuInspector(){}
    public static Result inspect(){
        String soc="Не определён";
        if(Build.VERSION.SDK_INT>=31){
            String m=Build.SOC_MANUFACTURER;String n=Build.SOC_MODEL;
            if(m!=null && !m.isEmpty() && n!=null && !n.isEmpty())soc=m+" "+n;
            else if(n!=null && !n.isEmpty())soc=n;
        }
        EGLDisplay display=EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if(display==EGL14.EGL_NO_DISPLAY) return new Result(soc,"Недоступно","—",0);
        EGLContext context=EGL14.EGL_NO_CONTEXT;
        EGLSurface surface=EGL14.EGL_NO_SURFACE;
        String renderer="Недоступно",vendor="—";
        int size=0;
        try{
            int[] version=new int[2];
            if(!EGL14.eglInitialize(display,version,0,version,1))return new Result(soc,renderer,vendor,size);
            int[] attr={EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE,EGL14.EGL_PBUFFER_BIT,EGL14.EGL_NONE};
            EGLConfig[] configs=new EGLConfig[1];int[] count=new int[1];
            if(!EGL14.eglChooseConfig(display,attr,0,configs,0,1,count,0) || count[0]<1)return new Result(soc,renderer,vendor,size);
            int[] ctxAttr={EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE};
            context=EGL14.eglCreateContext(display,configs[0],EGL14.EGL_NO_CONTEXT,ctxAttr,0);
            if(context==EGL14.EGL_NO_CONTEXT)return new Result(soc,renderer,vendor,size);
            int[] surfAttr={EGL14.EGL_WIDTH,1,EGL14.EGL_HEIGHT,1,EGL14.EGL_NONE};
            surface=EGL14.eglCreatePbufferSurface(display,configs[0],surfAttr,0);
            if(surface==EGL14.EGL_NO_SURFACE || !EGL14.eglMakeCurrent(display,surface,surface,context))
                return new Result(soc,renderer,vendor,size);
            String r=GLES20.glGetString(GLES20.GL_RENDERER);
            String v=GLES20.glGetString(GLES20.GL_VENDOR);
            if(r!=null && !r.isEmpty())renderer=r;
            if(v!=null && !v.isEmpty())vendor=v;
            int[] limits={0};GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE,limits,0);
            size=limits[0];
        }catch(Throwable ignore){
            // Some GPU drivers disallow PBuffer contexts. Do not block startup.
        }finally{
            if(context!=EGL14.EGL_NO_CONTEXT){
                EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT);
                if(surface!=EGL14.EGL_NO_SURFACE)EGL14.eglDestroySurface(display,surface);
                EGL14.eglDestroyContext(display,context);
            }
            EGL14.eglTerminate(display);
        }
        return new Result(soc,renderer,vendor,size);
    }
}
