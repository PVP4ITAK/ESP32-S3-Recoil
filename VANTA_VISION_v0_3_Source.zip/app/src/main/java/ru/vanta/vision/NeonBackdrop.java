package ru.vanta.vision;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/**
 * Original procedural cyberpunk / glitch artwork. No licensed template images are used.
 * Drawn through Android's hardware accelerated View canvas. No software layers,
 * offscreen bitmaps, or per-frame shader allocation.
 */
public final class NeonBackdrop extends View {
    private static final int DARK=0xFF060812;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path geometry=new Path();
    private Shader baseShader, tealGlow, violetGlow;
    private int targetFps=30, intensity=58;
    private long lastFrame=0;
    private float width,height;
    public NeonBackdrop(Context context){super(context);setWillNotDraw(false);}

    /** 0 = still; 15/30/45/60 are deliberately capped rendering rates. */
    public void setStyle(int framesPerSecond,int glitchIntensity){
        targetFps=Math.max(0,Math.min(60,framesPerSecond));
        intensity=Math.max(0,Math.min(100,glitchIntensity));
        lastFrame=0;
        invalidate();
    }
    @Override protected void onSizeChanged(int w,int h,int oldW,int oldH){
        super.onSizeChanged(w,h,oldW,oldH);
        width=w;height=h;
        if(w<2||h<2)return;
        baseShader=new LinearGradient(0,0,w,h,
                new int[]{DARK,0xFF10132A,0xFF0A1525,0xFF060812},
                new float[]{0f,.35f,.68f,1f},Shader.TileMode.CLAMP);
        tealGlow=new RadialGradient(w*.74f,h*.23f,Math.max(w,h)*.67f,
                new int[]{0x3B07C6BD,0x120891BA,0x00000000},null,Shader.TileMode.CLAMP);
        violetGlow=new RadialGradient(w*.21f,h*.82f,Math.max(w,h)*.57f,
                new int[]{0x46B629D4,0x1B7B1DA0,0x00000000},null,Shader.TileMode.CLAMP);
        geometry.reset();
        for(int k=-6;k<11;k++){
            float x=k*w/7f;
            geometry.moveTo(x,0);geometry.lineTo(x+w*.62f,h);
        }
    }
    private void color(int rgba,float stroke){paint.setColor(rgba);paint.setStrokeWidth(stroke);paint.setStyle(Paint.Style.STROKE);paint.setShader(null);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        final float w=width,h=height;
        if(w<2||h<2)return;
        final long now=SystemClock.uptimeMillis();
        final float second=now/1000f;
        final float unit=getResources().getDisplayMetrics().density;
        final float amount=intensity/100f;

        paint.setStyle(Paint.Style.FILL);paint.setColor(-1);paint.setShader(baseShader);
        canvas.drawRect(0,0,w,h,paint);
        paint.setShader(tealGlow);canvas.drawRect(0,0,w,h,paint);
        paint.setShader(violetGlow);canvas.drawRect(0,0,w,h,paint);paint.setShader(null);

        // Diagonal technical etchings cached as a Path; GPU draws one path per frame.
        color(0x132BD8E0,unit*.7f);
        canvas.drawPath(geometry,paint);

        // Thin scanlines are sparse on purpose: no full-screen shader texture.
        color(0x0EBDD1E8,unit*.6f);
        float pitch=28*unit;
        for(float y=0;y<h;y+=pitch){canvas.drawLine(0,y,w,y,paint);}

        // A low-contrast wireframe crest suggests a corrupted signal.
        float cx=w*.73f,cy=h*.57f;
        float wave= (float)Math.sin(second*.66f)*w*.016f;
        color(0x5527DBD1,unit*1.15f);
        canvas.drawLine(cx-w*.35f,cy+wave,cx-w*.06f,cy-h*.27f+wave,paint);
        canvas.drawLine(cx-w*.06f,cy-h*.27f+wave,cx+w*.25f,cy+wave,paint);
        color(0x53CB33B5,unit*.85f);
        canvas.drawLine(cx-w*.35f+2*unit,cy+wave+2*unit,cx-w*.06f+2*unit,cy-h*.27f+wave+2*unit,paint);
        canvas.drawLine(cx-w*.06f+2*unit,cy-h*.27f+wave+2*unit,cx+w*.25f+2*unit,cy+wave+2*unit,paint);

        // Moving scan seam and irregular twin-color slits: inspired by cyberpunk
        // glitch conventions, not by copied Adobe Stock source assets.
        if(targetFps>0){
            float scan=(second*.075f%1f)*h;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x1326F3E5);canvas.drawRect(0,scan-2*unit,w,scan+unit,paint);
            float burst=(float)Math.sin(second*3.7f);
            if(burst>.72f && amount>.03f){
                int bars=1+(int)(amount*4);
                for(int n=0;n<bars;n++){
                    float yy=(float)((n*.187+second*.039)%1f)*h;
                    float sl=3*unit+n*unit;
                    float xx=(float)((.11+n*.17+(Math.sin(second+n)*.05))%1f)*w;
                    paint.setColor((Math.round(amount*70)<<24)|0x00F035C6);
                    canvas.drawRect(xx,yy,Math.min(w,xx+w*(.23f+n*.045f)),yy+sl,paint);
                    paint.setColor((Math.round(amount*70)<<24)|0x0009DFDA);
                    canvas.drawRect(Math.max(0,xx-9*unit),yy-sl*.35f,Math.min(w,xx+w*.16f),yy+sl*.42f,paint);
                }
            }
        }

        // Framing graphics are static-ish and never interfere with taps.
        color(0x472BDECF,1.1f*unit);
        float pad=20*unit,len=24*unit;
        canvas.drawLine(pad,pad+len,pad,pad,paint);
        canvas.drawLine(pad,pad,pad+len,pad,paint);
        canvas.drawLine(w-pad-len,h-pad,w-pad,h-pad,paint);
        canvas.drawLine(w-pad,h-pad-len,w-pad,h-pad,paint);
        if(targetFps>0 && isAttachedToWindow() && getWindowVisibility()==VISIBLE && getVisibility()==VISIBLE){
            long frameMs=Math.max(16,1000L/targetFps);
            long due=Math.max(4,frameMs-(SystemClock.uptimeMillis()-now));
            lastFrame=now;
            postInvalidateDelayed(due);
        }
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();invalidate();}
    @Override protected void onVisibilityChanged(View changedView,int visibility){
        super.onVisibilityChanged(changedView,visibility);
        if(visibility==VISIBLE)invalidate();
    }
}
