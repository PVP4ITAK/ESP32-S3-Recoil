package ru.vanta.vision;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/** Touch-through display test HUD. No target detection or touch injection. */
public final class HudService extends Service {
    public static final String ACTION_HIDE = "ru.vanta.vision.HUD_HIDE";
    private WindowManager wm;
    private View overlay;
    @Override public IBinder onBind(Intent i) {return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && ACTION_HIDE.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(overlay!=null)return START_STICKY;
        try {
            wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            overlay=new HudView();
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.LEFT;lp.alpha=.70f;
            wm.addView(overlay,lp);VisionStatus.hudVisible=true;
        } catch(Exception ex){VisionStatus.error="HUD: "+ex.getMessage();stopSelf();}
        return START_STICKY;
    }
    @Override public void onDestroy(){
        if(wm!=null&&overlay!=null)try{wm.removeView(overlay);}catch(Exception ignored){}
        overlay=null;VisionStatus.hudVisible=false;super.onDestroy();
    }
    private final class HudView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        HudView(){super(HudService.this);}
        @Override protected void onDraw(Canvas c){
            float d=getResources().getDisplayMetrics().density;
            p.setColor(0xAA0FE9D6);p.setStrokeWidth(2*d);p.setStyle(Paint.Style.STROKE);
            float x=15*d,y=38*d,s=17*d;
            c.drawLine(x,y+s,x,y,p);c.drawLine(x,y,x+s,y,p);
            p.setStyle(Paint.Style.FILL);p.setTextSize(12*d);p.setTypeface(android.graphics.Typeface.create("monospace",1));
            c.drawText("VANTA • DEMO HUD",x+23*d,y+6*d,p);
            p.setColor(0xBBFFFFFF);p.setTextSize(9*d);
            c.drawText("NO MODEL / NO DETECTIONS",x+23*d,y+20*d,p);
            // Static HUD: no redraw loop while another app is in the foreground.
        }
    }
}
