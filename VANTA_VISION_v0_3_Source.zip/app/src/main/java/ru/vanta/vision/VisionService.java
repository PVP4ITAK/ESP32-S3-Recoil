package ru.vanta.vision;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

/** Real MediaProjection test: counts captured frames; does not run AI until a supported model is integrated. */
public final class VisionService extends Service {
    public static final String ACTION_START="ru.vanta.vision.CAPTURE_START";
    public static final String ACTION_STOP="ru.vanta.vision.CAPTURE_STOP";
    public static final String EXTRA_RESULT_CODE="resultCode";
    public static final String EXTRA_RESULT_DATA="resultData";
    private static final int ID=210;
    private static final String CHANNEL="vanta_capture";
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private MediaProjection.Callback callback;
    private ImageReader reader;
    private VirtualDisplay display;
    private long tickStart, intervalFrames;

    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!ACTION_START.equals(intent.getAction()))return START_NOT_STICKY;
        if(VisionStatus.capturing)return START_NOT_STICKY;
        createChannel();
        try {
            Notification n=notification();
            if(Build.VERSION.SDK_INT>=29)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(ID,n);
            int code=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED);
            Intent token;
            if(Build.VERSION.SDK_INT>=33)token=intent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class);
            else token=intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if(code!=Activity.RESULT_OK||token==null){stopSelf();return START_NOT_STICKY;}
            thread=new HandlerThread("vanta-capture");thread.start();
            worker=new Handler(thread.getLooper());
            worker.post(()->initProjection(code,token));
        } catch(Exception e){VisionStatus.error="Захват: "+e.getMessage();Log.e("Vanta", "Start failed",e);stopSelf();}
        return START_NOT_STICKY;
    }
    private void initProjection(int code,Intent token){
        try {
            MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=mgr.getMediaProjection(code,token);
            if(projection==null)throw new IllegalStateException("Не получено разрешение на экран");
            callback=new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}};
            projection.registerCallback(callback,worker);
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);
            float scale=Math.min(1f,960f/Math.max(m.widthPixels,m.heightPixels));
            int w=Math.max(64,Math.round(m.widthPixels*scale));
            int h=Math.max(64,Math.round(m.heightPixels*scale));
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            tickStart=SystemClock.elapsedRealtime();intervalFrames=0;VisionStatus.frames=0;
            reader.setOnImageAvailableListener(ir->{
                Image image=null;
                try {image=ir.acquireLatestImage();if(image!=null){VisionStatus.frames++;intervalFrames++;}}
                catch(Exception e){Log.w("Vanta","Frame error",e);}
                finally{if(image!=null)image.close();}
                long now=SystemClock.elapsedRealtime();
                if(now-tickStart>=1500){VisionStatus.sampleFps=intervalFrames*1000f/Math.max(1,now-tickStart);tickStart=now;intervalFrames=0;}
            },worker);
            display=projection.createVirtualDisplay("VantaPreview",w,h,m.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
            VisionStatus.capturing=true;VisionStatus.error="";
        }catch(Exception e){VisionStatus.error="Захват: "+e.getMessage();Log.e("Vanta","Projection failure",e);stopSelf();}
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"VANTA • захват экрана",NotificationManager.IMPORTANCE_LOW));}
    }
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent p=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop=new Intent(this,VisionService.class).setAction(ACTION_STOP);
        PendingIntent s=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("VANTA • экран")
                .setContentText("Тест захвата; распознавание ещё не подключено")
                .setContentIntent(p).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Остановить",s).build();
    }
    @Override public void onDestroy(){
        VisionStatus.capturing=false;VisionStatus.sampleFps=0;
        try{if(display!=null)display.release();}catch(Exception ignored){}display=null;
        try{if(reader!=null)reader.close();}catch(Exception ignored){}reader=null;
        try{if(projection!=null){if(callback!=null)projection.unregisterCallback(callback);projection.stop();}}catch(Exception ignored){}
        projection=null;callback=null;
        try{if(thread!=null)thread.quitSafely();}catch(Exception ignored){}thread=null;
        super.onDestroy();
    }
}
