package ru.vanta.vision;

public final class VisionStatus {
    public static volatile boolean capturing = false;
    public static volatile long frames = 0;
    public static volatile float sampleFps = 0;
    public static volatile String error = "";
    public static volatile boolean hudVisible = false;
    private VisionStatus() {}
}
