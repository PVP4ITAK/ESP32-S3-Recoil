package com.s3fire.overlay;

import android.content.Context;
import android.content.SharedPreferences;

final class Settings {
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("s3-fire", Context.MODE_PRIVATE); }
    static int duration(Context c) { return Math.max(200, Math.min(1800, prefs(c).getInt("duration", 850))); }
    static void duration(Context c, int ms) { prefs(c).edit().putInt("duration", ms).apply(); }
    static int x(Context c, int fallback) { return prefs(c).getInt("fireX", fallback); }
    static int y(Context c, int fallback) { return prefs(c).getInt("fireY", fallback); }
    static void position(Context c, int x, int y) { prefs(c).edit().putInt("fireX", x).putInt("fireY", y).apply(); }
    static int gun(Context c) { return prefs(c).getInt("gun",0); }
    static int scope(Context c) { return prefs(c).getInt("scope",0); }
    static void gun(Context c,int v) { prefs(c).edit().putInt("gun",v).apply(); }
    static void scope(Context c,int v) { prefs(c).edit().putInt("scope",v).apply(); }
    static final String[] GUNS={"M416","AUG","AKM","M762"};
    static final String[] SCOPES={"Red dot","2x","3x","4x","6x"};
    private Settings() {}
}
