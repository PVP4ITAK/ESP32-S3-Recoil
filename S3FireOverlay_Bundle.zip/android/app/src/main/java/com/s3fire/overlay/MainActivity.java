package com.s3fire.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView bleStatus, overlayStatus, durationLabel;
    private int dp(int v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private TextView text(String value,int size){
        TextView t=new TextView(this); t.setText(value);t.setTextSize(size);t.setTextColor(Color.rgb(30,40,55));
        t.setPadding(0,dp(7),0,dp(7));return t;
    }
    private Button button(String label){ Button b=new Button(this);b.setAllCaps(false);b.setText(label);return b; }
    private void add(LinearLayout l,View v){l.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setPadding(dp(20),dp(22),dp(20),dp(30));root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);setContentView(scroll);
        add(root,text("S3 FIRE OVERLAY · ПРОТОТИП",23));
        add(root,text("Плавающая тестовая зона поверх кнопки стрельбы. При одном касании запускает фиксированный короткий жест FIRE и BLE-команду ESP32. Это НЕ прозрачное удержание пальца.",15));
        bleStatus=text("BLE: не подключено",16); add(root,bleStatus);
        Button connect=button("1. Подключить ESP32 по Bluetooth");add(root,connect);
        connect.setOnClickListener(v->{
            if(!BleBridge.permissionsGranted(this))requestBlePermissions();
            else BleBridge.connect(this);
        });
        overlayStatus=text("Спецвозможности: выключены",15);add(root,overlayStatus);
        Button accessibility=button("2. Включить службу наложения");add(root,accessibility);
        accessibility.setOnClickListener(v->startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        add(root,text("Оружие (профили скорости берутся из ESP32)",16));
        Spinner guns=new Spinner(this);
        guns.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Settings2.guns()));
        guns.setSelection(com.s3fire.overlay.Settings.gun(this));add(root,guns);
        guns.setOnItemSelectedListener(new SimpleListener(){@Override public void onItemSelected(AdapterView<?> p, View v,int pos,long id){com.s3fire.overlay.Settings.gun(MainActivity.this,pos);}});
        add(root,text("Прицел",16));
        Spinner scopes=new Spinner(this);
        scopes.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Settings2.scopes()));
        scopes.setSelection(com.s3fire.overlay.Settings.scope(this));add(root,scopes);
        scopes.setOnItemSelectedListener(new SimpleListener(){@Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){com.s3fire.overlay.Settings.scope(MainActivity.this,pos);}});
        durationLabel=text("Длительность импульса: " + com.s3fire.overlay.Settings.duration(this) + " мс",16);add(root,durationLabel);
        SeekBar time=new SeekBar(this);time.setMax(1600);time.setProgress(com.s3fire.overlay.Settings.duration(this)-200);add(root,time);
        time.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int v,boolean from){int ms=v+200;com.s3fire.overlay.Settings.duration(MainActivity.this,ms);durationLabel.setText("Длительность импульса: "+ms+" мс");}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        Button calibrate=button("3. Показать / переместить зону ОГОНЬ");add(root,calibrate);
        calibrate.setOnClickListener(v->{
            if(!FireAccessibilityService.isRunning()){
                overlayStatus.setText("Сначала включи службу спецвозможностей");return;
            }
            FireAccessibilityService.setCalibrating(true);
        });
        Button arm=button("4. Включить тестовый режим");add(root,arm);
        arm.setOnClickListener(v->FireAccessibilityService.setCalibrating(false));
        add(root,text("Как работает: перетащи красную круглую область на позицию FIRE в режиме калибровки, затем включи тестовый режим. Один тап = один короткий импульс. Для корректной стрельбы при удержании нужна более сложная система и отдельное тестирование.",14));
        add(root,text("Внимание: вмешательство в управление PUBG может нарушать правила игры и повлечь блокировку. Проверяй сначала в приложении для рисования; совместимость с PUBG не гарантирована.",14));
    }
    private static class SimpleListener implements AdapterView.OnItemSelectedListener {
        public void onItemSelected(AdapterView<?> p,View v,int pos,long id){}
        public void onNothingSelected(AdapterView<?> p){}
    }
    private static class Settings2 {
        static String[] guns(){return com.s3fire.overlay.Settings.GUNS;}
        static String[] scopes(){return com.s3fire.overlay.Settings.SCOPES;}
    }
    private void requestBlePermissions(){
        if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},101);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},101);
    }
    @Override public void onRequestPermissionsResult(int request,String[] names,int[] grants){
        super.onRequestPermissionsResult(request,names,grants);
        if(request==101 && BleBridge.permissionsGranted(this))BleBridge.connect(this);
    }
    @Override protected void onResume(){super.onResume();
        BleBridge.setListener(()->{if(bleStatus!=null)bleStatus.setText("BLE: "+BleBridge.status());});
        if(overlayStatus!=null)overlayStatus.setText(FireAccessibilityService.isRunning()?"Спецвозможности: включены":"Спецвозможности: выключены");
    }
    @Override protected void onPause(){BleBridge.setListener(null);super.onPause();}
}
