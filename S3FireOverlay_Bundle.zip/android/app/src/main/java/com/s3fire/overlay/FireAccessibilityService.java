package com.s3fire.overlay;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Experimental fire overlay. The overlay intercepts the user's DOWN, becomes
 * non-touchable, then re-injects a FIXED-LENGTH stationary touch at the same
 * location using AccessibilityService.dispatchGesture(). This does not forward
 * a real held finger or monitor game touch events.
 */
public final class FireAccessibilityService extends AccessibilityService {
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static volatile FireAccessibilityService current;
    static boolean isRunning(){return current!=null;}
    static void setCalibrating(boolean value){
        FireAccessibilityService s=current;
        if(s!=null)MAIN.post(()->{if(current==s)s.calibration(value);});
    }

    private WindowManager wm;
    private LinearLayout panel;
    private TextView zone;
    private WindowManager.LayoutParams panelParams, zoneParams;
    private Button mode;
    private boolean calibrating=true, busy=false;
    private int dragX,dragY,initialX,initialY;
    private int dp(int size){return Math.round(getResources().getDisplayMetrics().density*size);}

    @Override protected void onServiceConnected(){
        super.onServiceConnected();current=this;
        wm=(WindowManager)getSystemService(Context.WINDOW_SERVICE);
        render();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){BleBridge.stopBurst();remove();current=null;super.onDestroy();}
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);remove();render();
    }

    private GradientDrawable bg(int color,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private WindowManager.LayoutParams params(int w,int h,int x,int y){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;p.x=x;p.y=y;
        return p;
    }
    private Button btn(String label){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(11);
        b.setTextColor(Color.WHITE);b.setBackground(bg(Color.rgb(42,60,84),9));return b;
    }
    private void render(){
        if(wm==null || zone!=null)return;
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(5),dp(5),dp(5),dp(5));panel.setBackground(bg(Color.rgb(19,29,43),12));
        mode=btn("ГОТОВО");
        panel.addView(mode,new LinearLayout.LayoutParams(dp(95),dp(45)));
        mode.setOnClickListener(v->calibration(!calibrating));
        panelParams=params(dp(105),dp(55),dp(10),dp(55));
        zone=new TextView(this);zone.setGravity(Gravity.CENTER);zone.setTextSize(12);
        zone.setTextColor(Color.WHITE);zone.setBackground(bg(Color.argb(210,205,44,55),100));
        int size=dp(86), width=getResources().getDisplayMetrics().widthPixels, height=getResources().getDisplayMetrics().heightPixels;
        zoneParams=params(size,size,Settings.x(this,Math.max(0,width-size-dp(80))),Settings.y(this,Math.max(0,height/2-size/2)));
        zone.setOnTouchListener((v,e)->handleTouch(e));
        try {wm.addView(panel,panelParams);wm.addView(zone,zoneParams);calibration(calibrating);}
        catch(RuntimeException ex){remove();Toast.makeText(this,"Не удалось показать наложение",Toast.LENGTH_LONG).show();}
    }
    private void calibration(boolean value){
        calibrating=value;
        if(mode!=null)mode.setText(value?"ГОТОВО":"ПЕРЕМЕСТИТЬ");
        if(zone!=null){zone.setText(value?"ПЕРЕТАЩИ\nОГОНЬ":"ОГОНЬ");zone.setAlpha(value?0.90f:0.35f);}
    }
    private boolean handleTouch(MotionEvent e){
        if(zoneParams==null)return true;
        if(calibrating){
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragX=(int)e.getRawX();dragY=(int)e.getRawY();
                    initialX=zoneParams.x;initialY=zoneParams.y;return true;
                case MotionEvent.ACTION_MOVE:
                    zoneParams.x=Math.max(0,initialX+(int)e.getRawX()-dragX);
                    zoneParams.y=Math.max(0,initialY+(int)e.getRawY()-dragY);
                    try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
                    return true;
                case MotionEvent.ACTION_UP:
                    Settings.position(this,zoneParams.x,zoneParams.y);return true;
                default:return true;
            }
        }
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN && !busy){fire();}
        return true;
    }

    private void fire(){
        if(!BleBridge.isReady()){
            Toast.makeText(this,"Сначала подключи BLE в приложении",Toast.LENGTH_SHORT).show();return;
        }
        busy=true;
        final int ms=Settings.duration(this);
        final int x=zoneParams.x+zoneParams.width/2, y=zoneParams.y+zoneParams.height/2;
        // Do not let our own accessibility-dispatched gesture hit the overlay.
        zoneParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
        MAIN.postDelayed(()->{
            if(!busy)return;
            // Begin the Android FIRE gesture before ESP32 starts USB HID touches.
            // dispatchGesture() may cancel touches already in progress.
            Path p=new Path();p.moveTo(x,y);
            GestureDescription gesture=new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p,0,ms)).build();
            boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription desc){finish();}
                @Override public void onCancelled(GestureDescription desc){finish();}
            },MAIN);
            if(!accepted){finish();return;}
            MAIN.postDelayed(()->{
                if(busy && !BleBridge.startBurst(Settings.gun(this),Settings.scope(this))){
                    Toast.makeText(this,"BLE отключилась",Toast.LENGTH_SHORT).show();
                    finish();
                }
            },65);
            MAIN.postDelayed(this::finish,ms+300);
        },70);
    }
    private void finish(){
        if(!busy)return;
        busy=false;BleBridge.stopBurst();
        if(zone!=null && zoneParams!=null){
            zoneParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
        }
    }
    private void remove(){
        if(wm!=null){
            if(zone!=null)try{wm.removeView(zone);}catch(Exception ignored){}
            if(panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}
        }
        zone=null;panel=null;zoneParams=null;panelParams=null;
        busy=false;
    }
}
