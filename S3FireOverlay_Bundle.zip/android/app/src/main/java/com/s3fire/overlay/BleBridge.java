package com.s3fire.overlay;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;

import java.util.Collections;
import java.util.UUID;

/** Bluetooth Low Energy transport, independent from internet/Wi-Fi. */
final class BleBridge {
    static final UUID SERVICE = UUID.fromString("91a11200-cc5a-4f18-a498-477000000001");
    static final UUID COMMAND = UUID.fromString("91a11200-cc5a-4f18-a498-477000000002");
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static BluetoothLeScanner scanner;
    private static ScanCallback scanCallback;
    private static BluetoothGatt gatt;
    private static BluetoothGattCharacteristic characteristic;
    private static Runnable listener;
    private static String status = "Не подключено";

    private static void update(String s) {
        status=s;
        if(listener!=null) MAIN.post(listener);
    }
    static void setListener(Runnable r) { listener=r; if(r!=null)MAIN.post(r); }
    static String status(){ return status; }
    static boolean isReady(){ return characteristic!=null && gatt!=null; }

    static boolean permissionsGranted(Context c) {
        if(Build.VERSION.SDK_INT>=31) {
            return c.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED
                    && c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        }
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    static synchronized void connect(Context context) {
        Context app=context.getApplicationContext();
        if(!permissionsGranted(app)){ update("Сначала разреши Bluetooth"); return; }
        try {
            BluetoothManager bm=(BluetoothManager)app.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter=bm==null?null:bm.getAdapter();
            if(adapter==null || !adapter.isEnabled()){ update("Включи Bluetooth на планшете");return; }
            if(isReady()){update("ESP32 подключена"); return;}
            stopScan();
            if(gatt!=null){gatt.close();gatt=null;}
            characteristic=null;
            scanner=adapter.getBluetoothLeScanner();
            if(scanner==null){update("BLE сканер недоступен");return;}
            update("Поиск S3-TouchProfiles-BLE...");
            scanCallback=new ScanCallback() {
                @Override public void onScanResult(int type, ScanResult result) {
                    if(scanCallback==null)return;
                    BluetoothDevice device=result.getDevice();
                    stopScan();
                    update("Подключение к ESP32...");
                    gatt=device.connectGatt(app,false,CALLBACK,BluetoothDevice.TRANSPORT_LE);
                }
                @Override public void onScanFailed(int code){ stopScan();update("Ошибка поиска BLE: " + code); }
            };
            ScanFilter filter=new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE)).build();
            ScanSettings settings=new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(filter),settings,scanCallback);
            MAIN.postDelayed(() -> {
                if(scanCallback!=null){stopScan();update("ESP32 не найдена. Нужна BLE-прошивка.");}
            },15000);
        } catch(Exception ex){update("Bluetooth: " + ex.getClass().getSimpleName());}
    }

    @SuppressLint("MissingPermission")
    private static synchronized void stopScan() {
        if(scanner!=null && scanCallback!=null){
            try{scanner.stopScan(scanCallback);}catch(Exception ignored){}
        }
        scanCallback=null;
    }

    private static final BluetoothGattCallback CALLBACK=new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g,int statusCode,int state) {
            if(state==BluetoothProfile.STATE_CONNECTED && statusCode==BluetoothGatt.GATT_SUCCESS){
                update("ESP32: поиск BLE-команды...");
                try{g.discoverServices();}catch(Exception ex){update("Не удалось найти сервис");}
            } else if(state==BluetoothProfile.STATE_DISCONNECTED) {
                characteristic=null;
                if(gatt==g)gatt=null;
                try{g.close();}catch(Exception ignored){}
                update("ESP32 отключена. Нажми «Подключить»");
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int result){
            if(result!=BluetoothGatt.GATT_SUCCESS){update("Ошибка BLE сервисов: " + result);return;}
            BluetoothGattService s=g.getService(SERVICE);
            characteristic=s==null?null:s.getCharacteristic(COMMAND);
            update(characteristic!=null?"ESP32 подключена · готово":"У ESP32 нет BLE-прошивки команд");
        }
    };

    @SuppressLint("MissingPermission")
    private static synchronized boolean send(byte[] bytes) {
        if(!isReady())return false;
        try {
            if(Build.VERSION.SDK_INT>=33){
                return gatt.writeCharacteristic(characteristic, bytes,
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)==0;
            }
            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            characteristic.setValue(bytes);
            return gatt.writeCharacteristic(characteristic);
        }catch(Exception ignored){return false;}
    }
    static boolean startBurst(int gun,int scope){
        return send(new byte[]{(byte)'F',(byte)('0'+gun),(byte)('0'+scope)});
    }
    static void stopBurst(){send(new byte[]{(byte)'0'});}
    private BleBridge(){}
}
