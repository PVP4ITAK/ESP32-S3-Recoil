package ru.pad7.aioverlay;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.tasks.components.containers.Detection;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Foreground MediaProjection -> local TFLite person detector -> non-touchable boxes. */
public final class CaptureService extends Service {
    public static final String ACTION_START = "ru.pad7.aioverlay.START";
    public static final String ACTION_STOP = "ru.pad7.aioverlay.STOP";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "pad7_ai_capture";
    private static final int NOTIFICATION_ID = 101;
    private static final String TAG = "Pad7AIOverlay";

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler worker;
    private WindowManager windowManager;
    private BoxesView boxesView;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private ImageReader reader;
    private VirtualDisplay display;
    private ObjectDetector detector;
    private long lastFrameTime;
    private boolean started;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || started) return START_NOT_STICKY;
        started = true;
        ensureChannel();
        try {
            Notification notification = makeNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else startForeground(NOTIFICATION_ID, notification);
        } catch (Exception e) {
            Log.e(TAG, "Cannot start foreground service", e);
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33)
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        else resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            boxesView = new BoxesView(this);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            // Below Android 12's default 0.8 maximum obscuring opacity for pass-through overlays.
            params.alpha = 0.70f;
            windowManager.addView(boxesView, params);
        } catch (Exception e) {
            Log.e(TAG, "Overlay permission missing or blocked", e);
            showToast("Нельзя нарисовать оверлей: проверь разрешение");
            stopSelf();
            return START_NOT_STICKY;
        }

        thread = new HandlerThread("Pad7AI-Inference");
        thread.start();
        worker = new Handler(thread.getLooper());
        final Intent token = resultData;
        worker.post(() -> initializeProjection(resultCode, token));
        return START_NOT_STICKY;
    }

    private void initializeProjection(int resultCode, Intent token) {
        try {
            ObjectDetector.ObjectDetectorOptions options = ObjectDetector.ObjectDetectorOptions.builder()
                    .setBaseOptions(BaseOptions.builder()
                            .setModelAssetPath("efficientdet_lite0.tflite").build())
                    .setRunningMode(RunningMode.IMAGE)
                    .setScoreThreshold(0.45f)
                    .setMaxResults(12)
                    .setCategoryAllowlist(Collections.singletonList("person"))
                    .build();
            detector = ObjectDetector.createFromOptions(this, options);

            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(resultCode, token);
            if (projection == null) throw new IllegalStateException("MediaProjection was null");
            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> stopSelf()); }
            };
            projection.registerCallback(projectionCallback, worker);

            DisplayMetrics metrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels, height = metrics.heightPixels;
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
            reader.setOnImageAvailableListener(this::processFrame, worker);
            display = projection.createVirtualDisplay(
                    "Pad7 AI Object Analyzer", width, height, metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, worker);
        } catch (Exception e) {
            Log.e(TAG, "Could not start capture/detector", e);
            showToast("Ошибка модели или захвата: " + e.getClass().getSimpleName());
            main.post(() -> stopSelf());
        }
    }

    private void processFrame(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null || detector == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastFrameTime < 450) return; // throttle: tablet performance / heat
            lastFrameTime = now;
            Image.Plane plane = image.getPlanes()[0];
            if (plane.getPixelStride() != 4) return;
            int width = image.getWidth(), height = image.getHeight();
            int strideWidth = plane.getRowStride() / plane.getPixelStride();
            ByteBuffer buffer = plane.getBuffer();
            buffer.rewind();
            Bitmap padded = Bitmap.createBitmap(strideWidth, height, Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            Bitmap sourceBitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
            padded.recycle();
            int scaledWidth = Math.min(640, width);
            int scaledHeight = Math.max(1, Math.round(height * (scaledWidth / (float) width)));
            Bitmap scaled = Bitmap.createScaledBitmap(sourceBitmap, scaledWidth, scaledHeight, true);
            sourceBitmap.recycle();
            MPImage mpImage = new BitmapImageBuilder(scaled).build();
            ObjectDetectorResult result = detector.detect(mpImage);
            List<RectF> rectangles = new ArrayList<>();
            for (Detection detection : result.detections()) {
                rectangles.add(new RectF(detection.boundingBox()));
            }
            main.post(() -> {
                if (boxesView != null) boxesView.updateBoxes(rectangles, scaledWidth, scaledHeight);
            });
            scaled.recycle();
        } catch (Exception e) {
            Log.w(TAG, "Dropping bad frame", e);
        } finally {
            if (image != null) image.close();
        }
    }

    private void ensureChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                "Распознавание экрана", NotificationManager.IMPORTANCE_LOW));
    }

    private Notification makeNotification() {
        Intent stop = new Intent(this, CaptureService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Pad7 AI Overlay")
                .setContentText("Локальное распознавание объектов включено")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Остановить", stopAction).build())
                .build();
    }

    private void showToast(String message) {
        main.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }

    @Override public void onDestroy() {
        if (reader != null) {
            reader.setOnImageAvailableListener(null, null);
        }
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (projection != null) {
            if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
            projection.stop();
            projection = null;
        }
        if (detector != null) { detector.close(); detector = null; }
        if (boxesView != null && windowManager != null) {
            try { windowManager.removeView(boxesView); } catch (Exception ignored) { }
            boxesView = null;
        }
        if (thread != null) { thread.quitSafely(); thread = null; }
        super.onDestroy();
    }
}
