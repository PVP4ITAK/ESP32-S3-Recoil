package ru.pad7.aioverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The application only analyzes the display; it never synthesizes touch or aim input. */
public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 701;
    private static final int NOTIFICATION_REQUEST = 702;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 24);
        TextView title = new TextView(this);
        title.setText("Pad7 AI Overlay — без ESP32");
        title.setTextSize(23);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Локальное распознавание людей на экране и рамки поверх приложений. Не управляет стрельбой или прицелом. Модель общего назначения, для PUBG не обучалась.\n\n1) Разреши отображение поверх других приложений.\n2) Начни захват экрана и выбери ВЕСЬ ЭКРАН.\n3) Открой приложение, которое разрешает захват. Остановка — через уведомление или кнопку ниже.");
        info.setTextSize(16);
        root.addView(info);
        Button overlay = new Button(this);
        overlay.setText("1. Разрешить поверх других окон");
        overlay.setOnClickListener(v -> requestOverlay());
        root.addView(overlay);
        Button start = new Button(this);
        start.setText("2. Запустить распознавание");
        start.setOnClickListener(v -> beginCapture());
        root.addView(start);
        Button stop = new Button(this);
        stop.setText("Остановить");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            status.setText("Остановка запрошена");
        });
        root.addView(stop);
        status = new TextView(this);
        status.setText("Ожидание разрешений");
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        }
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            status.setText("Разрешение поверх окон уже выдано");
        } else {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private void beginCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Сначала разреши отображение поверх других окон");
            requestOverlay();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), CAPTURE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Пользователь отменил захват экрана");
            return;
        }
        Intent s = new Intent(this, CaptureService.class);
        s.setAction(CaptureService.ACTION_START);
        s.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
        s.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
            else startService(s);
            status.setText("Запущен захват. Проверь уведомление и открой игру/приложение.");
        } catch (Exception ex) {
            status.setText("Не получилось запустить сервис: " + ex.getMessage());
        }
    }
}
