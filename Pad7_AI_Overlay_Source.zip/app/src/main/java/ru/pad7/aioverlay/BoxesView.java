package ru.pad7.aioverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Noninteractive drawing overlay. All coordinates refer to the scaled inference image. */
public final class BoxesView extends View {
    private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<RectF> boxes = new ArrayList<>();
    private int frameWidth = 1, frameHeight = 1;

    public BoxesView(Context context) {
        super(context);
        setWillNotDraw(false);
        setBackgroundColor(Color.TRANSPARENT);
    }

    public void updateBoxes(List<RectF> next, int sourceWidth, int sourceHeight) {
        boxes.clear();
        for (RectF b : next) boxes.add(new RectF(b));
        frameWidth = Math.max(1, sourceWidth);
        frameHeight = Math.max(1, sourceHeight);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float sx = getWidth() / (float) frameWidth;
        float sy = getHeight() / (float) frameHeight;
        pen.setColor(Color.rgb(65, 255, 165));
        pen.setStrokeWidth(Math.max(2f, getResources().getDisplayMetrics().density * 2));
        pen.setStyle(Paint.Style.STROKE);
        for (RectF b : boxes) {
            canvas.drawRect(b.left * sx, b.top * sy, b.right * sx, b.bottom * sy, pen);
        }
    }
}
