package ru.vanta.vision;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Rect;
import android.media.Image;
import android.os.SystemClock;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.TensorInfo;
import ai.onnxruntime.providers.NNAPIFlags;
import java.util.EnumSet;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads a static-size YOLO11n ONNX file (320/416/640 NCHW, output [1, 6, N]).
 * Postprocess: xywh and two class confidence scores, with per-class IoU NMS.
 * No interaction with any game or device input is performed.
 */
final class YoloDetector implements AutoCloseable {
    private final int side;
    private final long[] inputDims;
    private final int area;
    private final OrtEnvironment env;
    private final OrtSession.SessionOptions options;
    private final OrtSession session;
    private final String inputName;
    private final FloatBuffer input;
    private final OnnxTensor inputTensor;
    private final Map<String, OnnxTensor> inputMap;
    private final float[] tensor;
    private final Bitmap target;
    private final int[] pixels;
    private final Paint smooth = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final float[] normalize = new float[256];
    private final Canvas targetCanvas;
    private final Rect bitmapSourceRect = new Rect();
    private final RectF targetRect = new RectF();
    private Bitmap captureBitmap;
    private int[] capturePixels;
    private ByteBuffer packedRows;
    final boolean nnapiEnabled;
    final String engineName;
    private long lastMs;
    private long preprocessingMs, executionMs, postprocessingMs;

    YoloDetector(File model, boolean preferNnapi) throws Exception {
        if(!model.exists() || model.length()<1000000)
            throw new IllegalStateException("Загрузи файл PUBG_Body_Head.onnx во вкладке МОДЕЛЬ");
        env = OrtEnvironment.getEnvironment();
        for(int i=0;i<256;i++)normalize[i]=i/255f;
        OrtSession result = null;
        OrtSession.SessionOptions opts = null;
        boolean accelerated = false;
        String selectedEngine = "CPU";
        if(preferNnapi) {
            try {
                opts = makeOptions(true,false);
                result = env.createSession(model.getAbsolutePath(), opts);
                accelerated = true;
                selectedEngine = "NNAPI";
            }catch(Exception first){
                if(result!=null)try{result.close();}catch(Exception ignored){}
                if(opts!=null)try{opts.close();}catch(Exception ignored){}
                result = null; opts = null;
            }
        }
        if(result==null){
            // XNNPACK can be faster for FP32 convolutional models on Snapdragon CPUs.
            // Some device/ORT builds do not support it, so fall back cleanly.
            try {
                opts = makeOptions(false,true);
                result = env.createSession(model.getAbsolutePath(), opts);
                selectedEngine = "XNNPACK";
            } catch(Exception ex) {
                if(result!=null)try{result.close();}catch(Exception ignored){}
                if(opts!=null)try{opts.close();}catch(Exception ignored){}
                result=null; opts=null;
            }
        }
        if(result==null){
            opts=makeOptions(false,false);
            try{result=env.createSession(model.getAbsolutePath(),opts);}
            catch(Exception ex){opts.close();throw ex;}
            selectedEngine="CPU";
        }
        session = result;
        options = opts;
        nnapiEnabled = accelerated;
        engineName=selectedEngine;
        if(session.getInputNames().size()!=1)
            throw new IllegalArgumentException("Требуется ONNX с одним входом");
        inputName = session.getInputNames().iterator().next();
        NodeInfo ni=session.getInputInfo().get(inputName);
        if(!(ni.getInfo() instanceof TensorInfo))
            throw new IllegalArgumentException("Вход ONNX должен быть тензором");
        long[] shape=((TensorInfo)ni.getInfo()).getShape();
        if(shape.length!=4 || shape[0]!=1 || shape[1]!=3 || shape[2]!=shape[3] ||
            (shape[2]!=320 && shape[2]!=416 && shape[2]!=640))
            throw new IllegalArgumentException("Поддерживаются входы 1x3x320/416/640. Получено: "+java.util.Arrays.toString(shape));
        side=(int)shape[2];
        inputDims=new long[]{1,3,side,side};
        area=side*side;
        tensor=new float[3*area];
        pixels=new int[area];
        target=Bitmap.createBitmap(side,side,Bitmap.Config.ARGB_8888);
        targetCanvas=new Canvas(target);
        input=ByteBuffer.allocateDirect(3*area*Float.BYTES).order(ByteOrder.nativeOrder()).asFloatBuffer();
        inputTensor=OnnxTensor.createTensor(env,input,inputDims);
        inputMap=Collections.singletonMap(inputName,inputTensor);
    }

    private OrtSession.SessionOptions makeOptions(boolean useNnapi, boolean useXnnpack) throws OrtException {
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        try {
            // Avoid two competing thread-pools when XNNPACK owns convolutions.
            o.setIntraOpNumThreads(useXnnpack?1:4);
            o.setInterOpNumThreads(1);
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            if(useNnapi)o.addNnapi(EnumSet.of(NNAPIFlags.USE_FP16, NNAPIFlags.CPU_DISABLED));
            if(useXnnpack)o.addXnnpack(Collections.singletonMap("intra_op_num_threads", "4"));
            return o;
        } catch(OrtException ex) {o.close();throw ex;}
    }

    VisionStatus.Detection[] detect(Image frame, float confidence) throws Exception {
        long started = SystemClock.elapsedRealtime();
        int sourceW=frame.getWidth(),sourceH=frame.getHeight();
        Image.Plane plane=frame.getPlanes()[0];
        ByteBuffer bytes=plane.getBuffer();
        int pixelStride=plane.getPixelStride(), rowStride=plane.getRowStride();
        if(pixelStride<4)throw new IllegalArgumentException("Требуется RGBA_8888");
        // Zero per-pixel Java conversion when pixelStride is 4. Some Android
        // vendors omit padding on the final row: in that case pack whole rows
        // into a reusable direct buffer (instead of slow ByteBuffer.get per pixel).
        int bitmapWidth=(rowStride+3)/4;
        long lastRequired=(long)(sourceH-1)*rowStride + (long)sourceW*pixelStride;
        boolean rgbaRows=pixelStride==4 && rowStride>=sourceW*4 && bytes.limit()>=lastRequired;
        boolean directCopy=rgbaRows && rowStride%4==0 && bytes.limit()>=(long)rowStride*sourceH;
        int wantedWidth=directCopy?bitmapWidth:sourceW;
        if(captureBitmap==null || captureBitmap.getWidth()!=wantedWidth || captureBitmap.getHeight()!=sourceH){
            if(captureBitmap!=null)captureBitmap.recycle();
            captureBitmap=Bitmap.createBitmap(wantedWidth,sourceH,Bitmap.Config.ARGB_8888);
        }
        if(directCopy){
            bytes.rewind();
            captureBitmap.copyPixelsFromBuffer(bytes);
        } else if(rgbaRows){
            int needed=sourceW*sourceH*4;
            if(packedRows==null || packedRows.capacity()<needed)
                packedRows=ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder());
            packedRows.clear();
            ByteBuffer rowBytes=bytes.duplicate();
            for(int y=0;y<sourceH;y++){
                int rowStart=y*rowStride;
                rowBytes.limit(rowStart+sourceW*4);
                rowBytes.position(rowStart);
                packedRows.put(rowBytes);
            }
            packedRows.flip();
            captureBitmap.copyPixelsFromBuffer(packedRows);
        } else {
            if(capturePixels==null || capturePixels.length<sourceW*sourceH)
                capturePixels=new int[sourceW*sourceH];
            for(int y=0;y<sourceH;y++){
                int base=y*rowStride;
                for(int x=0;x<sourceW;x++){
                    int k=base+x*pixelStride;
                    int r=bytes.get(k)&255,g=bytes.get(k+1)&255,b=bytes.get(k+2)&255;
                    capturePixels[y*sourceW+x]=0xff000000|(r<<16)|(g<<8)|b;
                }
            }
            captureBitmap.setPixels(capturePixels,0,sourceW,0,0,sourceW,sourceH);
        }
        float gain=Math.min(side/(float)sourceW,side/(float)sourceH);
        float scaledW=sourceW*gain,scaledH=sourceH*gain;
        float padX=(side-scaledW)*0.5f,padY=(side-scaledH)*0.5f;
        targetCanvas.drawColor(Color.rgb(114,114,114));
        bitmapSourceRect.set(0,0,sourceW,sourceH);
        targetRect.set(padX,padY,padX+scaledW,padY+scaledH);
        targetCanvas.drawBitmap(captureBitmap,bitmapSourceRect,targetRect,smooth);
        target.getPixels(pixels,0,side,0,0,side,side);
        for(int i=0;i<area;i++){
            int argb=pixels[i];
            tensor[i]=normalize[(argb>>16)&255];
            tensor[area+i]=normalize[(argb>>8)&255];
            tensor[2*area+i]=normalize[argb&255];
        }
        input.clear();input.put(tensor);input.rewind();
        preprocessingMs=SystemClock.elapsedRealtime()-started;
        long networkStarted=SystemClock.elapsedRealtime();
        List<VisionStatus.Detection> boxes=new ArrayList<>();
        {
            try(OrtSession.Result result=session.run(inputMap)) {
                executionMs=SystemClock.elapsedRealtime()-networkStarted;
                Object value=result.get(0).getValue();
                if(!(value instanceof float[][][]))
                    throw new IllegalStateException("Неожиданный тип выхода ONNX");
                float[][][] output=(float[][][])value;
                if(output.length!=1 || output[0].length!=6)
                    throw new IllegalStateException("Ожидали выход [1,6,N]");
                float[][] a=output[0];
                int n=a[0].length;
                if(n<100 || n>10000) throw new IllegalStateException("Неожиданное число предсказаний: "+n);
                for(int i=0;i<n;i++){
                    float body=a[4][i],head=a[5][i];
                    float score=Math.max(body,head);
                    if(score<confidence)continue;
                    float cx=a[0][i],cy=a[1][i],bw=a[2][i],bh=a[3][i];
                    float left=clamp(((cx-bw/2f)-padX)/scaledW), top=clamp(((cy-bh/2f)-padY)/scaledH);
                    float right=clamp(((cx+bw/2f)-padX)/scaledW), bottom=clamp(((cy+bh/2f)-padY)/scaledH);
                    if(right-left<.002f || bottom-top<.002f)continue;
                    boxes.add(new VisionStatus.Detection(left,top,right,bottom,score,head>body?1:0));
                }
            }
        }
        boxes.sort((a,b)->Float.compare(b.score,a.score));
        List<VisionStatus.Detection> kept=new ArrayList<>();
        int cap=Math.min(boxes.size(),300);
        for(int i=0;i<cap && kept.size()<48;i++){
            VisionStatus.Detection candidate=boxes.get(i);
            boolean overlap=false;
            for(VisionStatus.Detection existing:kept){
                if(candidate.kind==existing.kind && iou(candidate,existing)>.50f){overlap=true;break;}
            }
            if(!overlap)kept.add(candidate);
        }
        lastMs=SystemClock.elapsedRealtime()-started;
        postprocessingMs=Math.max(0L,lastMs-preprocessingMs-executionMs);
        return kept.toArray(new VisionStatus.Detection[0]);
    }
    int getSide(){return side;}
    long getLastMs(){return lastMs;}
    long getPreprocessingMs(){return preprocessingMs;}
    long getExecutionMs(){return executionMs;}
    long getPostprocessingMs(){return postprocessingMs;}
    private static float clamp(float x){return Math.max(0f,Math.min(1f,x));}
    private static float iou(VisionStatus.Detection a,VisionStatus.Detection b){
        float x0=Math.max(a.left,b.left),y0=Math.max(a.top,b.top);
        float x1=Math.min(a.right,b.right),y1=Math.min(a.bottom,b.bottom);
        float intersection=Math.max(0,x1-x0)*Math.max(0,y1-y0);
        float aa=(a.right-a.left)*(a.bottom-a.top);
        float bb=(b.right-b.left)*(b.bottom-b.top);
        return intersection/Math.max(1e-6f,aa+bb-intersection);
    }
    @Override public void close() {
        inputTensor.close();
        try { session.close(); } catch (OrtException ignored) { }
        finally {
            options.close();
            target.recycle();
            if(captureBitmap!=null)captureBitmap.recycle();
        }
    }
}
