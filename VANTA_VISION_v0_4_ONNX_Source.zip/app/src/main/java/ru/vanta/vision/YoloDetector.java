package ru.vanta.vision;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.Image;
import android.os.SystemClock;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads the user's YOLO11n ONNX file (640x640 NCHW, output [1, 6, 8400]).
 * Postprocess: xywh and two class confidence scores, with per-class IoU NMS.
 * No interaction with any game or device input is performed.
 */
final class YoloDetector implements AutoCloseable {
    static final int SIDE = 640;
    private static final int BOXES = 8400;
    private static final long[] INPUT_DIMS = {1,3,SIDE,SIDE};
    private final OrtEnvironment env;
    private final OrtSession.SessionOptions options;
    private final OrtSession session;
    private final String inputName;
    private final FloatBuffer input;
    private final float[] tensor = new float[3*SIDE*SIDE];
    private final Bitmap target = Bitmap.createBitmap(SIDE,SIDE,Bitmap.Config.ARGB_8888);
    private final int[] pixels = new int[SIDE*SIDE];
    private final Paint smooth = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    final boolean nnapiEnabled;
    private long lastMs;

    YoloDetector(File model, boolean preferNnapi) throws Exception {
        if(!model.exists() || model.length()<1000000)
            throw new IllegalStateException("Загрузи файл PUBG_Body_Head.onnx во вкладке МОДЕЛЬ");
        env = OrtEnvironment.getEnvironment();
        input = ByteBuffer.allocateDirect(3*SIDE*SIDE*Float.BYTES).order(ByteOrder.nativeOrder()).asFloatBuffer();
        OrtSession result = null;
        OrtSession.SessionOptions opts = null;
        boolean accelerated = false;
        if(preferNnapi) {
            try {
                opts = makeOptions(true);
                result = env.createSession(model.getAbsolutePath(), opts);
                accelerated = true;
            }catch(Exception first){
                if(result!=null)try{result.close();}catch(Exception ignored){}
                if(opts!=null)try{opts.close();}catch(Exception ignored){}
                result = null; opts = null;
            }
        }
        if(result==null){
            opts = makeOptions(false);
            try{result = env.createSession(model.getAbsolutePath(), opts);}
            catch(Exception ex){opts.close();throw ex;}
        }
        session = result;
        options = opts;
        nnapiEnabled = accelerated;
        if(session.getInputNames().size()!=1)
            throw new IllegalArgumentException("Требуется ONNX с одним входом 1x3x640x640");
        inputName = session.getInputNames().iterator().next();
    }

    private OrtSession.SessionOptions makeOptions(boolean useNnapi) throws OrtException {
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        o.setIntraOpNumThreads(3);
        o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
        if(useNnapi)o.addNnapi();
        return o;
    }

    VisionStatus.Detection[] detect(Image frame, float confidence) throws Exception {
        long started = SystemClock.elapsedRealtime();
        int sourceW=frame.getWidth(),sourceH=frame.getHeight();
        Image.Plane plane=frame.getPlanes()[0];
        ByteBuffer bytes=plane.getBuffer();
        int pixelStride=plane.getPixelStride(), rowStride=plane.getRowStride();
        if(pixelStride<4)throw new IllegalArgumentException("Требуется RGBA_8888");
        int[] sourcePixels=new int[sourceW*sourceH];
        for(int y=0;y<sourceH;y++){
            int base=y*rowStride;
            for(int x=0;x<sourceW;x++){
                int k=base+x*pixelStride;
                int r=bytes.get(k)&255,g=bytes.get(k+1)&255,b=bytes.get(k+2)&255;
                sourcePixels[y*sourceW+x]=Color.rgb(r,g,b);
            }
        }
        Bitmap source=Bitmap.createBitmap(sourcePixels,sourceW,sourceH,Bitmap.Config.ARGB_8888);
        float gain=Math.min(SIDE/(float)sourceW,SIDE/(float)sourceH);
        float scaledW=sourceW*gain,scaledH=sourceH*gain;
        float padX=(SIDE-scaledW)*0.5f,padY=(SIDE-scaledH)*0.5f;
        Canvas canvas=new Canvas(target);
        canvas.drawColor(Color.rgb(114,114,114));
        canvas.drawBitmap(source,null,new RectF(padX,padY,padX+scaledW,padY+scaledH),smooth);
        source.recycle();
        target.getPixels(pixels,0,SIDE,0,0,SIDE,SIDE);
        for(int i=0;i<pixels.length;i++){
            int argb=pixels[i];
            tensor[i]=((argb>>16)&255)/255f;
            tensor[SIDE*SIDE+i]=((argb>>8)&255)/255f;
            tensor[2*SIDE*SIDE+i]=(argb&255)/255f;
        }
        input.clear();input.put(tensor);input.rewind();
        List<VisionStatus.Detection> boxes=new ArrayList<>();
        try(OnnxTensor t=OnnxTensor.createTensor(env,input,INPUT_DIMS)) {
            Map<String,OnnxTensor> m=Collections.singletonMap(inputName,t);
            try(OrtSession.Result result=session.run(m)) {
                Object value=result.get(0).getValue();
                if(!(value instanceof float[][][]))
                    throw new IllegalStateException("Неожиданный тип выхода ONNX");
                float[][][] output=(float[][][])value;
                if(output.length!=1 || output[0].length!=6 || output[0][0].length!=BOXES)
                    throw new IllegalStateException("Ожидали выход [1,6,8400]");
                float[][] a=output[0];
                for(int i=0;i<BOXES;i++){
                    float body=a[4][i],head=a[5][i];
                    float score=Math.max(body,head);
                    if(score<confidence)continue;
                    float cx=a[0][i],cy=a[1][i],bw=a[2][i],bh=a[3][i];
                    float left=clamp(((cx-bw/2f)-padX)/scaledW), top=clamp(((cy-bh/2f)-padY)/scaledH);
                    float right=clamp(((cx+bw/2f)-padX)/scaledW), bottom=clamp(((cy+bh/2f)-padY)/scaledH);
                    if(right-left<.002f || bottom-top<.002f)continue;
                    boxes.add(new VisionStatus.Detection(left,top,right,bottom,score,head>body?1:0));
                }
            }
        }
        boxes.sort((a,b)->Float.compare(b.score,a.score));
        List<VisionStatus.Detection> kept=new ArrayList<>();
        int cap=Math.min(boxes.size(),300);
        for(int i=0;i<cap && kept.size()<48;i++){
            VisionStatus.Detection candidate=boxes.get(i);
            boolean overlap=false;
            for(VisionStatus.Detection existing:kept){
                if(candidate.kind==existing.kind && iou(candidate,existing)>.50f){overlap=true;break;}
            }
            if(!overlap)kept.add(candidate);
        }
        lastMs=SystemClock.elapsedRealtime()-started;
        return kept.toArray(new VisionStatus.Detection[0]);
    }
    long getLastMs(){return lastMs;}
    private static float clamp(float x){return Math.max(0f,Math.min(1f,x));}
    private static float iou(VisionStatus.Detection a,VisionStatus.Detection b){
        float x0=Math.max(a.left,b.left),y0=Math.max(a.top,b.top);
        float x1=Math.min(a.right,b.right),y1=Math.min(a.bottom,b.bottom);
        float intersection=Math.max(0,x1-x0)*Math.max(0,y1-y0);
        float aa=(a.right-a.left)*(a.bottom-a.top);
        float bb=(b.right-b.left)*(b.bottom-b.top);
        return intersection/Math.max(1e-6f,aa+bb-intersection);
    }
    @Override public void close() {
        try { session.close(); } catch (OrtException ignored) { }
        try { options.close(); } catch (OrtException ignored) { }
    }
}
