package ru.vanta.vision;

import java.util.ArrayList;
import java.util.List;

/**
 * UI-only box stabilization. It never generates user input or changes the ONNX results.
 * Matcher associates same-class boxes across inference results; animator blends them
 * between inference results. New tracks appear immediately; still tracks resist jitter.
 * All calls happen on the overlay UI thread.
 */
final class SmoothTracker {
    private final List<Track> tracks = new ArrayList<>();
    private static final int MAX_TRACKS = 32;
    // If neural inference is slow, keep the last measured rectangle stable
    // across the gap. This is visualization only, not a fresh detection.
    private static long maxStaleMs() {
        return Math.max(350L, Math.min(1200L, (long)(VisionStatus.inferenceMs*2.2f+300)));
    }
    private static final float JITTER_CENTER = 0.006f;
    private static final float JITTER_SIZE = 0.008f;

    static final class Track {
        final int id;
        final int kind;
        float cx, cy, w, h;           // current, animated state
        float tx, ty, tw, th;        // newest observed state
        float score;
        long lastSeenMs;
        boolean matched;
        Track(int id, VisionStatus.Detection d, long now) {
            this.id = id;
            kind = d.kind;
            cx = tx = (d.left + d.right)*0.5f;
            cy = ty = (d.top + d.bottom)*0.5f;
            w = tw = Math.max(0.001f, d.right-d.left);
            h = th = Math.max(0.001f, d.bottom-d.top);
            score = d.score;
            lastSeenMs = now;
        }
        float left() { return Math.max(0, cx-w*.5f); }
        float top() { return Math.max(0, cy-h*.5f); }
        float right() { return Math.min(1, cx+w*.5f); }
        float bottom() { return Math.min(1, cy+h*.5f); }
        float opacity(long now) {
            long age = Math.max(0L, now-lastSeenMs);
            long ttl=maxStaleMs();
            long fadeStart=Math.max(200L,Math.round(ttl*.7f));
            if(age < fadeStart)return 1f;
            return Math.max(0f, 1f-(age-fadeStart)/(float)(ttl-fadeStart));
        }
    }
    private int nextId = 1;
    private long lastAdvanceMs;

    List<Track> getTracks() { return tracks; }

    void reset() {
        tracks.clear();
        lastAdvanceMs = 0;
    }

    void accept(VisionStatus.Detection[] detections, long now) {
        for (Track t : tracks) t.matched = false;
        // Greedy nearest-neighbour matching with same-class and size-aware distance.
        for (VisionStatus.Detection d : detections) {
            float dcx = (d.left+d.right)*0.5f, dcy=(d.top+d.bottom)*0.5f;
            float dw = d.right-d.left, dh=d.bottom-d.top;
            Track best = null;
            float bestCost = Float.MAX_VALUE;
            for (Track t : tracks) {
                if (t.matched || t.kind!=d.kind) continue;
                float dist = (float)Math.hypot(dcx-t.tx, dcy-t.ty);
                float gate = Math.min(.22f, Math.max(.035f, Math.max(dw,t.tw)*1.20f + .025f));
                if (dist>gate) continue;
                float sizePenalty = Math.abs(dw-t.tw)*.12f + Math.abs(dh-t.th)*.12f;
                float cost = dist + sizePenalty;
                if (cost < bestCost) { bestCost=cost; best=t; }
            }
            if (best==null) {
                if (tracks.size()<MAX_TRACKS) {
                    Track created=new Track(nextId++,d,now);
                    created.matched=true;
                    tracks.add(created);
                }
            } else {
                best.matched = true;
                // Quantization/threshold jitter is common even on still targets.
                // Small changes are ignored; large movements are followed responsively.
                if (Math.abs(dcx-best.tx)>JITTER_CENTER) best.tx = dcx;
                if (Math.abs(dcy-best.ty)>JITTER_CENTER) best.ty = dcy;
                if (Math.abs(dw-best.tw)>JITTER_SIZE) best.tw = dw;
                if (Math.abs(dh-best.th)>JITTER_SIZE) best.th = dh;
                best.score = d.score;
                best.lastSeenMs = now;
            }
        }
        tracks.removeIf(t -> now-t.lastSeenMs>maxStaleMs());
    }

    void advance(long now) {
        if(lastAdvanceMs==0) { lastAdvanceMs=now; return; }
        float dt = Math.max(0.001f, Math.min(0.10f, (now-lastAdvanceMs)/1000f));
        lastAdvanceMs=now;
        for (Track t : tracks) {
            // Adaptive spring: large motion reacts faster; tiny motion is stabilized.
            float delta = (float)Math.hypot(t.tx-t.cx,t.ty-t.cy);
            float tau = delta>.04f ? .055f : delta>.015f ? .090f : .150f;
            float alpha = 1f-(float)Math.exp(-dt/tau);
            t.cx += (t.tx-t.cx)*alpha;
            t.cy += (t.ty-t.cy)*alpha;
            t.w  += (t.tw-t.w)*alpha;
            t.h  += (t.th-t.h)*alpha;
        }
        tracks.removeIf(t -> now-t.lastSeenMs>maxStaleMs());
    }
}
