package ru.vanta.vision;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;

/** Captures screen via MediaProjection and runs user-imported ONNX, if present. */
public final class VisionService extends Service {
    public static final String ACTION_START="ru.vanta.vision.CAPTURE_START";
    public static final String ACTION_STOP="ru.vanta.vision.CAPTURE_STOP";
    public static final String EXTRA_RESULT_CODE="resultCode";
    public static final String EXTRA_RESULT_DATA="resultData";
    private static final int ID=210;
    private static final String CHANNEL="vanta_capture";
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private MediaProjection.Callback callback;
    private ImageReader reader;
    private VirtualDisplay display;
    private YoloDetector detector;
    private long tickStart,intervalFrames,lastInference;
    private boolean started=false;

    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!ACTION_START.equals(intent.getAction()))return START_NOT_STICKY;
        if(started)return START_NOT_STICKY;
        started=true;
        createChannel();
        try {
            Notification n=notification();
            if(Build.VERSION.SDK_INT>=29)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(ID,n);
            int code=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED);
            Intent token;
            if(Build.VERSION.SDK_INT>=33)token=intent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class);
            else token=intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if(code!=Activity.RESULT_OK||token==null){stopSelf();return START_NOT_STICKY;}
            VisionStatus.error="";
            VisionStatus.modelReady=false;
            VisionStatus.detections=new VisionStatus.Detection[0];
            thread=new HandlerThread("vanta-onnx-capture");thread.start();
            worker=new Handler(thread.getLooper());
            worker.post(()->initProjection(code,token));
        }catch(Exception e){VisionStatus.error="Захват: "+e.getMessage();Log.e("Vanta", "Start failed",e);stopSelf();}
        return START_NOT_STICKY;
    }

    private void initProjection(int code,Intent token){
        try {
            File model=new File(getFilesDir(),"imported_model.dat");
            if(model.exists()){
                boolean requestNnapi=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("preferNNAPI",false);
                try{
                    detector=new YoloDetector(model,requestNnapi);
                    VisionStatus.modelReady=true;
                    VisionStatus.nnapiActive=detector.nnapiEnabled;
                }catch(Exception e){
                    VisionStatus.error="Модель: "+e.getMessage();
                    Log.w("Vanta", "ONNX model failed to initialize", e);
                    detector=null;
                }
            }
            MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=mgr.getMediaProjection(code,token);
            if(projection==null)throw new IllegalStateException("Не получено разрешение на экран");
            callback=new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}};
            projection.registerCallback(callback,worker);
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);
            float scale=Math.min(1f,960f/Math.max(m.widthPixels,m.heightPixels));
            int w=Math.max(64,Math.round(m.widthPixels*scale));
            int h=Math.max(64,Math.round(m.heightPixels*scale));
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,3);
            tickStart=SystemClock.elapsedRealtime();intervalFrames=0;lastInference=0;
            VisionStatus.frames=0;VisionStatus.inferenceCount=0;VisionStatus.inferenceMs=0;
            reader.setOnImageAvailableListener(ir->{
                Image image=null;
                try {
                    image=ir.acquireLatestImage();
                    if(image!=null){
                        VisionStatus.frames++;intervalFrames++;
                        long now=SystemClock.elapsedRealtime();
                        // A single worker thread runs the detector; drop excess frames.
                        if(detector!=null && now-lastInference>=350){
                            lastInference=now;
                            float conf=getSharedPreferences("settings",MODE_PRIVATE).getInt("detectorConfidence",45)/100f;
                            VisionStatus.Detection[] found=detector.detect(image,conf);
                            VisionStatus.detections=found;
                            VisionStatus.inferenceMs=detector.getLastMs();
                            VisionStatus.inferenceCount++;
                        }
                    }
                }catch(Exception e){
                    VisionStatus.error="Инференс: "+e.getMessage();
                    Log.e("Vanta", "Frame failed",e);
                }finally{if(image!=null)image.close();}
                long now=SystemClock.elapsedRealtime();
                if(now-tickStart>=1500){
                    VisionStatus.sampleFps=intervalFrames*1000f/Math.max(1,now-tickStart);
                    tickStart=now;intervalFrames=0;
                }
            },worker);
            display=projection.createVirtualDisplay("VantaVision",w,h,m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
            VisionStatus.capturing=true;
            if(Settings.canDrawOverlays(this))startService(new Intent(this,HudService.class));
        }catch(Exception e){
            VisionStatus.error="Захват: "+e.getMessage();
            Log.e("Vanta", "Projection failure",e);
            stopSelf();
        }
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"VANTA • захват экрана",NotificationManager.IMPORTANCE_LOW));}
    }
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent p=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop=new Intent(this,VisionService.class).setAction(ACTION_STOP);
        PendingIntent s=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("VANTA VISION")
            .setContentText("Захват экрана и локальное распознавание при наличии ONNX-модели")
            .setContentIntent(p).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Остановить",s).build();
    }
    @Override public void onDestroy(){
        VisionStatus.capturing=false;VisionStatus.sampleFps=0;VisionStatus.modelReady=false;
        VisionStatus.nnapiActive=false;VisionStatus.detections=new VisionStatus.Detection[0];
        try{if(display!=null)display.release();}catch(Exception ignored){}display=null;
        try{if(reader!=null)reader.close();}catch(Exception ignored){}reader=null;
        try{if(projection!=null){if(callback!=null)projection.unregisterCallback(callback);projection.stop();}}catch(Exception ignored){}
        projection=null;callback=null;
        final YoloDetector closing=detector;detector=null;
        if(worker!=null && thread!=null){
            worker.post(()->{if(closing!=null)try{closing.close();}catch(Exception ignored){}});
            thread.quitSafely();
        }else if(closing!=null)try{closing.close();}catch(Exception ignored){}
        thread=null;worker=null;
        super.onDestroy();
    }
}
