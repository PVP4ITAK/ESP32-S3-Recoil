package ru.vanta.vision;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicBoolean;

/** Captures screen via MediaProjection and runs user-imported ONNX, if present. */
public final class VisionService extends Service {
    public static final String ACTION_START="ru.vanta.vision.CAPTURE_START";
    public static final String ACTION_STOP="ru.vanta.vision.CAPTURE_STOP";
    public static final String EXTRA_RESULT_CODE="resultCode";
    public static final String EXTRA_RESULT_DATA="resultData";
    private static final int ID=210;
    private static final String CHANNEL="vanta_capture";
    private HandlerThread thread;
    private Handler worker;
    private HandlerThread inferenceThread;
    private Handler inferenceWorker;
    private final AtomicReference<Image> latestFrame=new AtomicReference<>();
    private final AtomicBoolean inferenceScheduled=new AtomicBoolean(false);
    private MediaProjection projection;
    private MediaProjection.Callback callback;
    private ImageReader reader;
    private VirtualDisplay display;
    private YoloDetector detector;
    private long tickStart,intervalFrames;
    private long inferTickStart, inferTickCount;
    private volatile boolean started=false;

    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!ACTION_START.equals(intent.getAction()))return START_NOT_STICKY;
        if(started)return START_NOT_STICKY;
        started=true;
        createChannel();
        try {
            Notification n=notification();
            if(Build.VERSION.SDK_INT>=29)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(ID,n);
            int code=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED);
            Intent token;
            if(Build.VERSION.SDK_INT>=33)token=intent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class);
            else token=intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if(code!=Activity.RESULT_OK||token==null){stopSelf();return START_NOT_STICKY;}
            VisionStatus.error="";
            VisionStatus.modelReady=false;
            VisionStatus.detections=new VisionStatus.Detection[0];
            VisionStatus.inferenceEngine="CPU";
            thread=new HandlerThread("vanta-onnx-capture");thread.start();
            worker=new Handler(thread.getLooper());
            worker.post(()->initProjection(code,token));
        }catch(Exception e){VisionStatus.error="Захват: "+e.getMessage();Log.e("Vanta", "Start failed",e);stopSelf();}
        return START_NOT_STICKY;
    }

    private void initProjection(int code,Intent token){
        try {
            File model=new File(getFilesDir(),"imported_model.dat");
            if(model.exists()){
                boolean requestNnapi=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("preferNNAPI",false);
                try{
                    detector=new YoloDetector(model,requestNnapi);
                    VisionStatus.modelReady=true;
                    VisionStatus.modelInputSize=detector.getSide();
                    VisionStatus.nnapiActive=detector.nnapiEnabled;
                    VisionStatus.inferenceEngine=detector.engineName;
                }catch(Exception e){
                    VisionStatus.error="Модель: "+e.getMessage();
                    Log.w("Vanta", "ONNX model failed to initialize", e);
                    detector=null;
                }
            }
            MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=mgr.getMediaProjection(code,token);
            if(projection==null)throw new IllegalStateException("Не получено разрешение на экран");
            callback=new MediaProjection.Callback(){
                @Override public void onStop(){stopSelf();}
                // Android 14+ notifies on display rotation and capture resize.
                @Override public void onCapturedContentResize(int width,int height){
                    if(worker!=null)worker.post(()->resizeCapture(width,height));
                }
            };
            projection.registerCallback(callback,worker);
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);
            // Match the capture resolution to the actual ONNX input: 320/416/640.
            // Scaling 320p input up into a 640 model does not accelerate the ONNX graph.
            int modelSide=detector==null?640:detector.getSide();
            float scale=Math.min(1f,modelSide/(float)Math.max(m.widthPixels,m.heightPixels));
            int w=Math.max(64,Math.round(m.widthPixels*scale));
            int h=Math.max(64,Math.round(m.heightPixels*scale));
            inferenceThread=new HandlerThread("vanta-onnx-infer");
            inferenceThread.start();
            inferenceWorker=new Handler(inferenceThread.getLooper());
            // Two held images (current inference + newest pending), leave two free
            // for acquireLatestImage to discard outdated frames.
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,4);
            tickStart=SystemClock.elapsedRealtime();intervalFrames=0;
            inferTickStart=tickStart;inferTickCount=0;
            VisionStatus.frames=0;VisionStatus.inferenceCount=0;VisionStatus.inferenceMs=0;
            VisionStatus.inferenceFps=0;
            VisionStatus.preprocessMs=0;VisionStatus.neuralMs=0;VisionStatus.postprocessMs=0;
            reader.setOnImageAvailableListener(this::handleFrame,worker);
            display=projection.createVirtualDisplay("VantaVision",w,h,m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
            VisionStatus.captureRevision++;
            VisionStatus.capturing=true;
            if(Settings.canDrawOverlays(this))startService(new Intent(this,HudService.class));
        }catch(Exception e){
            VisionStatus.error="Захват: "+e.getMessage();
            Log.e("Vanta", "Projection failure",e);
            stopSelf();
        }
    }
    /** The capture looper never waits for ONNX: newest-frame-wins, queue length one. */
    private void handleFrame(ImageReader ir) {
        Image image=null;
        try {
            image=ir.acquireLatestImage();
            if(image==null)return;
            VisionStatus.frames++;
            intervalFrames++;
            if(detector!=null && inferenceWorker!=null && started) {
                Image replaced=latestFrame.getAndSet(image);
                image=null; // ownership transferred to the pending slot
                if(replaced!=null)replaced.close();
                scheduleInference();
            }
        }catch(Exception e){
            VisionStatus.error="Захват: "+e.getMessage();
            Log.w("Vanta","Capture failed",e);
        }finally{
            if(image!=null)image.close();
        }
        long now=SystemClock.elapsedRealtime();
        if(now-tickStart>=1500){
            VisionStatus.sampleFps=intervalFrames*1000f/Math.max(1,now-tickStart);
            tickStart=now;
            intervalFrames=0;
        }
    }

    private void scheduleInference() {
        if(inferenceWorker!=null && started && inferenceScheduled.compareAndSet(false,true)) {
            inferenceWorker.post(this::processLatestFrame);
        }
    }

    private void processLatestFrame() {
        Image image=latestFrame.getAndSet(null);
        try {
            if(started && image!=null && detector!=null){
                float conf=getSharedPreferences("settings",MODE_PRIVATE)
                    .getInt("detectorConfidence",45)/100f;
                VisionStatus.Detection[] found=detector.detect(image,conf);
                VisionStatus.preprocessMs=detector.getPreprocessingMs();
                VisionStatus.neuralMs=detector.getExecutionMs();
                VisionStatus.postprocessMs=detector.getPostprocessingMs();
                VisionStatus.inferenceMs=detector.getLastMs();
                VisionStatus.detections=found;
                VisionStatus.inferenceCount++;
                inferTickCount++;
                long t=SystemClock.elapsedRealtime();
                if(t-inferTickStart>=1500){
                    VisionStatus.inferenceFps=inferTickCount*1000f/Math.max(1L,t-inferTickStart);
                    inferTickStart=t;inferTickCount=0;
                }
            }
        }catch(Exception e){
            VisionStatus.error="Инференс: "+e.getMessage();
            Log.e("Vanta", "Inference failed",e);
        }finally {
            if(image!=null)image.close();
            inferenceScheduled.set(false);
            // A frame acquired during inference replaces older pending frames.
            if(latestFrame.get()!=null) scheduleInference();
        }
    }
    private void resizeCapture(int contentWidth,int contentHeight) {
        if(contentWidth<64 || contentHeight<64 || display==null || worker==null)return;
        try {
            int modelSide=detector==null?640:detector.getSide();
            float scale=Math.min(1f,modelSide/(float)Math.max(contentWidth,contentHeight));
            int w=Math.max(64,Math.round(contentWidth*scale));
            int h=Math.max(64,Math.round(contentHeight*scale));
            if(reader!=null && reader.getWidth()==w && reader.getHeight()==h)return;
            ImageReader fresh=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,4);
            fresh.setOnImageAvailableListener(this::handleFrame,worker);
            display.resize(w,h,getResources().getDisplayMetrics().densityDpi);
            display.setSurface(fresh.getSurface());
            ImageReader previous=reader;
            reader=fresh;
            if(previous!=null){previous.setOnImageAvailableListener(null,null);previous.close();}
            VisionStatus.detections=new VisionStatus.Detection[0];
            Image pending=latestFrame.getAndSet(null);
            if(pending!=null)pending.close();
            VisionStatus.captureRevision++;
            VisionStatus.error="";
        } catch(Exception e) {
            VisionStatus.error="Поворот экрана: "+e.getMessage();
            Log.w("Vanta","Resize capture failed",e);
        }
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"VANTA • захват экрана",NotificationManager.IMPORTANCE_LOW));}
    }
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent p=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop=new Intent(this,VisionService.class).setAction(ACTION_STOP);
        PendingIntent s=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("VANTA VISION")
            .setContentText("Захват экрана и локальное распознавание при наличии ONNX-модели")
            .setContentIntent(p).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Остановить",s).build();
    }
    @Override public void onDestroy(){
        started=false;
        Image pending=latestFrame.getAndSet(null);
        if(pending!=null)pending.close();
        VisionStatus.capturing=false;VisionStatus.sampleFps=0;VisionStatus.inferenceFps=0;VisionStatus.modelReady=false;
        VisionStatus.nnapiActive=false;VisionStatus.detections=new VisionStatus.Detection[0];
        VisionStatus.inferenceEngine="CPU";
        VisionStatus.modelInputSize=0;
        try{if(display!=null)display.release();}catch(Exception ignored){}display=null;
        try{if(reader!=null)reader.close();}catch(Exception ignored){}reader=null;
        try{if(projection!=null){if(callback!=null)projection.unregisterCallback(callback);projection.stop();}}catch(Exception ignored){}
        projection=null;callback=null;
        final YoloDetector closing=detector;detector=null;
        if(inferenceWorker!=null && inferenceThread!=null){
            inferenceWorker.post(()->{if(closing!=null)try{closing.close();}catch(Exception ignored){}});
            inferenceThread.quitSafely();
        }else if(closing!=null)try{closing.close();}catch(Exception ignored){}
        if(thread!=null)thread.quitSafely();
        inferenceThread=null;inferenceWorker=null;
        thread=null;worker=null;
        super.onDestroy();
    }
}
