package ru.vanta.vision;

public final class VisionStatus {
    public static volatile boolean capturing = false;
    public static volatile boolean modelReady = false;
    public static volatile boolean nnapiActive = false;
    public static volatile long frames = 0;
    public static volatile float sampleFps = 0;
    public static volatile float inferenceFps = 0;
    public static volatile long inferenceMs = 0;
    public static volatile long preprocessMs = 0;
    public static volatile long neuralMs = 0;
    public static volatile long postprocessMs = 0;
    public static volatile String inferenceEngine = "CPU";
    public static volatile long inferenceCount = 0;
    public static volatile int modelInputSize = 0;
    public static volatile long captureRevision = 0;
    public static volatile String error = "";
    public static volatile boolean hudVisible = false;
    public static volatile Detection[] detections = new Detection[0];

    public static final class Detection {
        public final float left, top, right, bottom, score;
        public final int kind;
        public Detection(float l,float t,float r,float b,float score,int kind){
            this.left=l;this.top=t;this.right=r;this.bottom=b;this.score=score;this.kind=kind;
        }
    }
    private VisionStatus() {}
}
