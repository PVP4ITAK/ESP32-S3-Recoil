package ru.vanta.vision;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

/** Original Android UI inspired by high-contrast sci-fi dashboards; no NAIM components are copied. */
public final class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST=401;
    private static final int TRACK_REQUEST=402;
    private static final int MODEL_REQUEST=403;
    private static final int ALERT_REQUEST=404;
    private static final int BG=0xFF080D18, CARD=0xE8101929, LINE=0xFF26374A;
    private static final int CYAN=0xFF27E6D4, BLUE=0xFF7DC6FF, WHITE=0xFFE6F3FD, MUTED=0xFFA1B1C6, PURPLE=0xFF9B86F8;
    private static final String[] TABS={"ОБЗОР","ЗАХВАТ","ВИЗУАЛ","МОДЕЛЬ","АУДИО","СИСТЕМА"};
    private int tab=0;
    private LinearLayout host;
    private NeonBackdrop backdrop;
    private volatile GpuInspector.Result detectedGpu;
    private TextView gpuReadout, socReadout;
    private TextView statusLabel;
    private TextView footStats;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){@Override public void run(){
        if(statusLabel!=null){String label=VisionStatus.capturing?(VisionStatus.modelReady?"ONNX · "+VisionStatus.inferenceMs+" ms":"ЗАХВАТ АКТИВЕН"): (modelSaved()?"МОДЕЛЬ ЗАГРУЖЕНА":"НЕТ МОДЕЛИ");
            statusLabel.setText(label);statusLabel.setTextColor(VisionStatus.capturing?CYAN:MUTED);}
        if(footStats!=null)footStats.setText("CAPTURE "+(VisionStatus.capturing?"ONLINE":"OFFLINE")+"  /  ONNX "+(VisionStatus.modelReady?"ACTIVE":"IDLE")+"  /  "+(MusicService.playing?"AUDIO PLAYING":"AUDIO IDLE"));
        ui.postDelayed(this,1200);
    }};

    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        getWindow().setStatusBarColor(0xFF060A13);getWindow().setNavigationBarColor(0xFF060A13);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showScreen();
        new Thread(()->{
            GpuInspector.Result r=GpuInspector.inspect();
            runOnUiThread(()->{
                detectedGpu=r;
                if(gpuReadout!=null)gpuReadout.setText("GPU: "+r.renderer);
                if(socReadout!=null)socReadout.setText("Чипсет: "+r.soc);
                if(backdrop!=null)applyBackdropProfile();
            });
        },"gpu-info").start();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},ALERT_REQUEST);
    }
    @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);showScreen();}
    @Override protected void onResume(){super.onResume();ui.removeCallbacks(refresh);ui.post(refresh);}
    @Override protected void onPause(){ui.removeCallbacks(refresh);super.onPause();}
    @Override protected void onDestroy(){ui.removeCallbacks(refresh);super.onDestroy();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int bg,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView txt(String s,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);
        v.setFontFeatureSettings("kern");v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        return v;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void space(LinearLayout into,int h){View v=new View(this);into.addView(v,lp(1,h));}
    private void line(LinearLayout into){View v=new View(this);v.setBackgroundColor(LINE);into.addView(v,lp(-1,1));}
    private void label(LinearLayout into,String t){TextView v=txt(t,11,CYAN,true);v.setLetterSpacing(.16f);into.addView(v);space(into,10);}
    private LinearLayout card(LinearLayout into){LinearLayout b=col();b.setPadding(dp(18),dp(17),dp(18),dp(17));b.setBackground(shape(CARD,LINE,16));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(14);into.addView(b,p);return b;}
    private TextView action(String text,boolean filled,View.OnClickListener click){
        TextView v=txt(text,13,filled?0xFF04131A:WHITE,true);v.setGravity(Gravity.CENTER);
        v.setPadding(dp(15),dp(13),dp(15),dp(13));v.setBackground(shape(filled?CYAN:0xFF182537,filled?CYAN:LINE,11));
        v.setOnClickListener(click);return v;
    }
    private void addButton(LinearLayout parent,String text,boolean filled,View.OnClickListener click){
        TextView b=action(text,filled,click);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);parent.addView(b,p);
    }
    private void pair(LinearLayout into,String key,String value,int valueColor){
        LinearLayout l=row();TextView a=txt(key,13,MUTED,false);TextView b=txt(value,12,valueColor,true);
        LinearLayout.LayoutParams x=lp(0,-2);x.weight=1;l.addView(a,x);l.addView(b);
        into.addView(l);space(into,10);
    }
    private void applyBackdropProfile(){
        if(backdrop==null)return;
        int mode=getSharedPreferences("settings",MODE_PRIVATE).getInt("vantaAnimationMode",0);
        int strength=getSharedPreferences("settings",MODE_PRIVATE).getInt("vantaGlitchIntensity",58);
        float hz=getWindowManager().getDefaultDisplay().getRefreshRate();
        int adrenoAuto=hz>=140?48:hz>=116?40:hz>=85?45:30;
        int fps=(mode==1?15:mode==2?30:mode==3?60:mode==4?0:(detectedGpu!=null && detectedGpu.adreno?adrenoAuto:30));
        backdrop.setStyle(fps,strength);
    }
    private void saveAnimationMode(int mode){
        getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("vantaAnimationMode",mode).apply();
        showScreen();
    }
    private void showScreen(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        backdrop=new NeonBackdrop(this);applyBackdropProfile();
        root.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout stack=col();stack.setPadding(dp(14),dp(8),dp(14),dp(10));root.addView(stack,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=row();header.setPadding(dp(12),dp(14),dp(8),dp(16));
        LinearLayout brand=col();TextView name=txt("VANTA VISION",22,WHITE,true);name.setLetterSpacing(.15f);brand.addView(name);
        TextView subtitle=txt("NEURAL INTERFACE     //     MOBILE",10,CYAN,true);subtitle.setLetterSpacing(.12f);brand.addView(subtitle);
        LinearLayout.LayoutParams wt=lp(0,-2);wt.weight=1;header.addView(brand,wt);
        LinearLayout pill=col();pill.setPadding(dp(12),dp(8),dp(12),dp(8));pill.setBackground(shape(0xDD112134,LINE,10));
        statusLabel=txt(modelSaved()?"МОДЕЛЬ ЗАГРУЖЕНА":"НЕТ МОДЕЛИ",10,MUTED,true);pill.addView(statusLabel);header.addView(pill);stack.addView(header);
        View hr=new View(this);hr.setBackgroundColor(LINE);stack.addView(hr,lp(-1,1));space(stack,12);
        int wide=getResources().getConfiguration().screenWidthDp>=680?1:0;
        if(wide==1){
            LinearLayout body=row();body.setGravity(Gravity.TOP);
            LinearLayout nav=col();nav.setPadding(dp(8),dp(15),dp(12),0);nav.setBackground(shape(0xC7101928,LINE,16));
            TextView ctl=txt("CONTROL PANEL",10,MUTED,true);ctl.setLetterSpacing(.2f);nav.addView(ctl);space(nav,14);
            for(int k=0;k<TABS.length;k++){
                final int selected=k;TextView entry=navEntry(k);
                LinearLayout.LayoutParams p=lp(-1,48);p.bottomMargin=dp(8);nav.addView(entry,p);
                entry.setOnClickListener(v->{tab=selected;showScreen();});
            }
            space(nav,28);line(nav);space(nav,15);
            TextView n=txt(modelSaved()?"NEURAL CORE\nONNX IMPORTED":"NEURAL CORE\nIMPORT ONNX",12,MUTED,true);nav.addView(n);
            body.addView(nav,lp(204,-1));
            ScrollView scroll=contentScroll();LinearLayout.LayoutParams x=lp(0,-1);x.weight=1;x.leftMargin=dp(14);body.addView(scroll,x);
            LinearLayout.LayoutParams expand=lp(-1,0);expand.weight=1;stack.addView(body,expand);
        }else{
            HorizontalScrollView navScroll=new HorizontalScrollView(this);navScroll.setHorizontalScrollBarEnabled(false);
            LinearLayout entries=row();for(int k=0;k<TABS.length;k++){
                final int selected=k;TextView e=navEntry(k);LinearLayout.LayoutParams pp=lp(-2,44);pp.rightMargin=dp(7);entries.addView(e,pp);e.setOnClickListener(v->{tab=selected;showScreen();});
            }navScroll.addView(entries);stack.addView(navScroll);space(stack,10);
            ScrollView scroll=contentScroll();LinearLayout.LayoutParams expand=lp(-1,0);expand.weight=1;stack.addView(scroll,expand);
        }
        footStats=txt("CAPTURE OFFLINE  /  ONNX IDLE  /  AUDIO IDLE",9,MUTED,true);footStats.setPadding(dp(9),dp(12),0,dp(5));footStats.setLetterSpacing(.05f);stack.addView(footStats);
        setContentView(root);
    }
    private TextView navEntry(int k){TextView t=txt((tab==k?"▸  ":"   ")+TABS[k],12,tab==k?CYAN:MUTED,true);
        t.setPadding(dp(14),dp(10),dp(14),dp(10));t.setGravity(Gravity.CENTER_VERTICAL);t.setBackground(shape(tab==k?0xCC143B46:0x55111B29,tab==k?0xFF236F75:0x00263545,10));return t;}
    private ScrollView contentScroll(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setVerticalScrollBarEnabled(false);
        host=col();host.setPadding(dp(6),dp(5),dp(6),dp(18));scroll.addView(host);
        switch(tab){case 0:overview();break;case 1:capturePage();break;case 2:visualPage();break;case 3:modelPage();break;case 4:audioPage();break;default:systemPage();}
        return scroll;}
    private void title(String eyebrow,String heading,String desc){TextView e=txt(eyebrow,11,CYAN,true);e.setLetterSpacing(.22f);host.addView(e);space(host,9);
        TextView h=txt(heading,26,WHITE,true);host.addView(h);space(host,6);
        TextView sub=txt(desc,13,MUTED,false);sub.setLineSpacing(dp(3),1);host.addView(sub);space(host,19);
    }
    private void overview(){
        title("SYSTEM / DASHBOARD","Всё готово к подключению модели","Панель управления захватом, визуальными эффектами и музыкой. Модуль распознавания подключим после обучения.");
        LinearLayout hero=card(host);label(hero,"VISION CORE   //   v0.4");
        TextView slogan=txt("YOUR SCREEN.\nYOUR VISION.",29,WHITE,true);slogan.setLetterSpacing(.06f);hero.addView(slogan);space(hero,12);
        TextView explanation=txt("Локальный детектор Body / Head по модели YOLO11n. Импортируй .onnx и включи захват экрана. Обработка проходит на устройстве; точность и скорость проверяются отдельно.",13,MUTED,false);hero.addView(explanation);space(hero,16);
        addButton(hero,"▶  ПЕРЕЙТИ К ЗАХВАТУ",true,v->switchTab(1));
        LinearLayout check=card(host);label(check,"СИСТЕМНЫЕ МОДУЛИ");
        pair(check,"Экран Android",VisionStatus.capturing?"АКТИВЕН":"ГОТОВ К ТЕСТУ",VisionStatus.capturing?CYAN:BLUE);
        pair(check,"Модель Head / Body",VisionStatus.modelReady?"РАБОТАЕТ":(modelSaved()?"ИМПОРТИРОВАНА":"НЕ ПОДКЛЮЧЕНА"),VisionStatus.modelReady?CYAN:(modelSaved()?BLUE:MUTED));
        pair(check,"Прозрачный HUD",VisionStatus.hudVisible?"ВКЛЮЧЁН":"ВЫКЛЮЧЕН",VisionStatus.hudVisible?CYAN:MUTED);
        pair(check,"Фоновая музыка",MusicService.playing?"ИГРАЕТ":"ПАУЗА",MusicService.playing?CYAN:MUTED);
        LinearLayout quick=card(host);label(quick,"БЫСТРЫЕ ДЕЙСТВИЯ");
        addButton(quick,"♪  Настроить музыку",false,v->switchTab(4));
        addButton(quick,"◈  Тест оверлея",false,v->switchTab(2));
    }
    private void capturePage(){
        title("CAPTURE / PIPELINE","Захват и распознавание","MediaProjection → YOLO11n ONNX → рамки Body / Head. Используется локальная модель, если она импортирована.");
        LinearLayout b=card(host);label(b,"FRAME CAPTURE");
        pair(b,"Состояние",VisionStatus.capturing?"ONLINE":"OFFLINE",VisionStatus.capturing?CYAN:MUTED);
        pair(b,"Частота получения кадров",String.format(Locale.US,"%.1f FPS",VisionStatus.sampleFps),BLUE);
        pair(b,"Получено кадров",String.valueOf(VisionStatus.frames),WHITE);
        pair(b,"Обработано нейросетью",String.valueOf(VisionStatus.inferenceCount),CYAN);
        pair(b,"Скорость распознавания",String.format(Locale.US,"%.1f FPS",VisionStatus.inferenceFps),CYAN);
        pair(b,"Полная обработка кадра",VisionStatus.modelReady?VisionStatus.inferenceMs+" мс":"—",BLUE);
        pair(b,"Подготовка изображения",VisionStatus.modelReady?VisionStatus.preprocessMs+" мс":"—",MUTED);
        pair(b,"Выполнение нейросети",VisionStatus.modelReady?VisionStatus.neuralMs+" мс":"—",CYAN);
        pair(b,"Обработка обнаружений",VisionStatus.modelReady?VisionStatus.postprocessMs+" мс":"—",MUTED);
        pair(b,"Вычислительный движок",VisionStatus.modelReady?VisionStatus.inferenceEngine:"НЕ ЗАПУЩЕН",PURPLE);
        pair(b,"Размер входа ONNX",VisionStatus.modelInputSize>0?VisionStatus.modelInputSize+" × "+VisionStatus.modelInputSize:"—",CYAN);
        pair(b,"Фоновая очередь кадров","МАКСИМУМ 1 СВЕЖИЙ",BLUE);
        addButton(b,"01  /  Разрешить оверлей",false,v->requestOverlay());
        addButton(b,"02  /  Начать захват экрана",true,v->requestCapture());
        addButton(b,"■  Остановить захват",false,v->{stopService(new Intent(this,VisionService.class));toast("Захват остановлен");showScreen();});
        LinearLayout note=card(host);label(note,"ВАЖНО");
        note.addView(txt("После запуска Android спросит, разрешать ли запись или показ экрана. Выбери «Весь экран», если система предлагает выбор. Некоторые приложения могут блокировать захват; это зависит от Android и самого приложения.",13,MUTED,false));
        if(!VisionStatus.error.isEmpty()){space(note,12);note.addView(txt(VisionStatus.error,12,0xFFFFB1AD,false));}
    }
    private void visualPage(){
        title("VISUAL / OVERLAY","Визуальные эффекты","Анимированный глитч-фон и HUD с рамками Body / Head. Касания и управление игрой не выполняются.");
        LinearLayout b=card(host);label(b,"HUD LAYER");
        pair(b,"Режим",VisionStatus.modelReady?"LIVE DETECTIONS":"DEMO / NO MODEL",VisionStatus.modelReady?CYAN:PURPLE);
        pair(b,"Сквозное касание","ВКЛЮЧЕНО",CYAN);
        addButton(b,"◈  Включить HUD",true,v->{if(!Settings.canDrawOverlays(this)){requestOverlay();return;}startService(new Intent(this,HudService.class));toast("HUD включён");showScreen();});
        addButton(b,"■  Выключить HUD",false,v->{stopService(new Intent(this,HudService.class));toast("HUD выключен");showScreen();});
        LinearLayout fx=card(host);label(fx,"CYBERPUNK GLITCH / LIVE BACKGROUND");
        pair(fx,"Отрисовка","АППАРАТНЫЙ CANVAS",CYAN);
        int mode=getSharedPreferences("settings",MODE_PRIVATE).getInt("vantaAnimationMode",0);
        String[] modes={"AUTO","ЭКО · 15 FPS","БАЛАНС · 30 FPS","ПЛАВНО · 60 FPS","СТАТИЧНО"};
        pair(fx,"Режим анимации",modes[Math.max(0,Math.min(mode,4))],BLUE);
        addButton(fx,"◈  Автоматическая адаптация",mode==0,v->saveAnimationMode(0));
        addButton(fx,"◇  Экономия энергии · 15 FPS",mode==1,v->saveAnimationMode(1));
        addButton(fx,"◈  Баланс · 30 FPS",mode==2,v->saveAnimationMode(2));
        addButton(fx,"✧  Плавно · 60 FPS",mode==3,v->saveAnimationMode(3));
        addButton(fx,"■  Отключить анимацию",mode==4,v->saveAnimationMode(4));
        label(fx,"СИЛА ГЛИТЧ-ЭФФЕКТА");
        SeekBar intensityBar=new SeekBar(this);
        intensityBar.setMax(100);
        intensityBar.setProgress(getSharedPreferences("settings",MODE_PRIVATE).getInt("vantaGlitchIntensity",58));
        intensityBar.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        intensityBar.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));
        intensityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int v,boolean user){if(user){getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("vantaGlitchIntensity",v).apply();applyBackdropProfile();}}
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });
        fx.addView(intensityBar);
        LinearLayout note=card(host);label(note,"ПОЗЖЕ");
        note.addView(txt("HUD: плавная отрисовка ~30 FPS, привязка рамок к объектам и подавление дрожания. Реальная частота распознавания зависит от времени ONNX; сглаживание не заменяет новые кадры. HUD не управляет игрой.",13,MUTED,false));
    }
    private void modelPage(){
        title("AI / ENGINE","Модель распознавания","Вычислительный движок ONNX Runtime для двух классов: Body / Head. Модель работает локально, без отправки кадров в интернет.");
        LinearLayout b=card(host);label(b,"MODEL MANAGER / YOLO11N");
        pair(b,"Файл",modelSaved()?"ИМПОРТИРОВАН":"НЕ НАЙДЕН",modelSaved()?CYAN:MUTED);
        String filename=getSharedPreferences("settings",MODE_PRIVATE).getString("modelName","—");
        pair(b,"Имя",shorten(filename,28),WHITE);
        pair(b,"Статус",VisionStatus.modelReady?"РАБОТАЕТ":(modelSaved()?"ГОТОВ К ЗАПУСКУ":"ОЖИДАЕТ ФАЙЛ"),VisionStatus.modelReady?CYAN:BLUE);
        pair(b,"Вход",VisionStatus.modelInputSize>0?"1 × 3 × "+VisionStatus.modelInputSize+" × "+VisionStatus.modelInputSize:"Авто: 320 / 416 / 640",BLUE);
        pair(b,"Выход", "1 × 6 × N",BLUE);
        pair(b,"Классы", "BODY / HEAD",CYAN);
        addButton(b,"＋  Импортировать PUBG_Body_Head.onnx",true,v->pickModel());
        addButton(b,"×  Удалить модель",false,v->{
            if(VisionStatus.capturing){toast("Сначала останови захват");return;}
            getFilesDirFile().delete();getSharedPreferences("settings",MODE_PRIVATE).edit().remove("modelName").apply();showScreen();
        });
        LinearLayout threshold=card(host);label(threshold,"НАСТРОЙКИ ОБНАРУЖЕНИЯ");
        final int value=getSharedPreferences("settings",MODE_PRIVATE).getInt("detectorConfidence",45);
        pair(threshold,"Порог уверенности",value+"%",BLUE);
        SeekBar confidenceSlider=new SeekBar(this);
        confidenceSlider.setMax(80);confidenceSlider.setProgress(Math.max(0,Math.min(80,value-10)));
        confidenceSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        confidenceSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));
        confidenceSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int v,boolean user){
                if(user)getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("detectorConfidence",10+v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){showScreen();}
        });threshold.addView(confidenceSlider);
        boolean preferNnapi=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("preferNNAPI",false);
        addButton(threshold,preferNnapi?"●  NNAPI: включено (экспериментально)":"○  NNAPI: выключено / CPU",false,v->{
            getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("preferNNAPI",!preferNnapi).apply();
            toast("Настройка применится после перезапуска захвата");showScreen();
        });
        LinearLayout explain=card(host);label(explain,"ДВИЖОК И УСКОРЕНИЕ");
        explain.addView(txt("Быстрый режим: импортируй статическую модель 320×320 или 416×416, затем перезапусти захват. XNNPACK использует 4 CPU-потока; NNAPI FP16 экспериментален. Уменьшение размера ускоряет инференс, но может ухудшить распознавание мелких целей. Настоящий Qualcomm QNN/GPU здесь ещё не подключён.",13,MUTED,false));
        if(!VisionStatus.error.isEmpty()){space(explain,12);explain.addView(txt(VisionStatus.error,12,0xFFFFB1AD,false));}
    }
    private void audioPage(){
        title("AUDIO / PLAYER","Саундтрек приложения","Выбери MP3 из памяти планшета. Воспроизведение циклическое и может продолжаться после сворачивания интерфейса.");
        LinearLayout b=card(host);label(b,"LOCAL MUSIC ENGINE");
        TextView track=txt("THE REBEL PATH\nCELLO VERSION",22,WHITE,true);track.setLetterSpacing(.03f);b.addView(track);space(b,10);
        TextView credit=txt("Cyberpunk 2077 OST • локальный файл пользователя",11,MUTED,false);b.addView(credit);space(b,15);
        String stored=getSharedPreferences("settings",MODE_PRIVATE).getString("musicName",null);
        pair(b,"Выбрано",stored==null?"ТРЕК НЕ ВЫБРАН":shorten(stored,30),stored==null?MUTED:CYAN);
        pair(b,"Воспроизведение",MusicService.playing?"▶ ИГРАЕТ":"Ⅱ ПАУЗА",MusicService.playing?CYAN:MUTED);
        addButton(b,"▣  Выбрать MP3 / аудиофайл",false,v->pickMusic());
        addButton(b,"▶  Воспроизводить по кругу",true,v->commandMusic(MusicService.PLAY));
        addButton(b,"Ⅱ  Пауза",false,v->commandMusic(MusicService.PAUSE));
        addButton(b,"■  Выключить музыку",false,v->commandMusic(MusicService.STOP));
        space(b,9);label(b,"ГРОМКОСТЬ МУЗЫКИ");
        SeekBar slider=new SeekBar(this);slider.setMax(100);slider.setProgress(getSharedPreferences("settings",MODE_PRIVATE).getInt("musicVol",35));
        slider.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        slider.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar sb,int level,boolean fromUser){if(fromUser){getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("musicVol",level).apply();
                if(MusicService.playing){Intent i=new Intent(MainActivity.this,MusicService.class).setAction(MusicService.VOL);i.putExtra(MusicService.EXTRA_VOLUME,level);startService(i);}}}
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });b.addView(slider);
        LinearLayout note=card(host);label(note,"ПРАВА НА МУЗЫКУ");
        note.addView(txt("Музыка не включена в публичный APK и исходники. Приложение играет только выбранный тобой локальный файл. Для публикации APK с включённой записью потребуется разрешение правообладателя.",12,MUTED,false));
        if(!MusicService.lastError.isEmpty()){space(note,9);note.addView(txt(MusicService.lastError,12,0xFFFFB1AD,false));}
    }
    private void systemPage(){
        title("SYSTEM / ABOUT","Настройки и статус","Состояние графического движка, производительность и разрешения приложения.");
        LinearLayout b=card(host);label(b,"DEVICE");
        pair(b,"Устройство",Build.MANUFACTURER+" "+Build.MODEL,WHITE);
        pair(b,"Android",String.valueOf(Build.VERSION.RELEASE),WHITE);
        TextView socRow=txt("Чипсет: "+(detectedGpu!=null?detectedGpu.soc:"Определяется…"),12,MUTED,false);
        b.addView(socRow);socReadout=socRow;space(b,10);
        TextView gpuRow=txt("GPU: "+(detectedGpu!=null?detectedGpu.renderer:"Определяется…"),12,BLUE,false);
        b.addView(gpuRow);gpuReadout=gpuRow;space(b,10);
        pair(b,"Графика","HARDWARE ACCELERATED",CYAN);
        pair(b,"Режим",detectedGpu!=null && detectedGpu.adreno?"ADRENO / AUTO":"УНИВЕРСАЛЬНЫЙ",BLUE);
        pair(b,"Разрешение оверлея",Settings.canDrawOverlays(this)?"РАЗРЕШЕНО":"НУЖНО РАЗРЕШИТЬ",Settings.canDrawOverlays(this)?CYAN:MUTED);
        pair(b,"Версия приложения","0.5 SPEED / LIVE",BLUE);
        addButton(b,"Открыть разрешение оверлея",false,v->requestOverlay());
        LinearLayout perf=card(host);label(perf,"ПРОИЗВОДИТЕЛЬНОСТЬ");
        perf.addView(txt("Скоростной режим: отдельные потоки захвата/инференса, единственный свежий кадр, переиспользование тензора и модели 320/416/640. XNNPACK CPU и экспериментальный NNAPI FP16. Snapdragon QNN/Adreno пока не подключён.",13,MUTED,false));
        LinearLayout note=card(host);label(note,"ПРОЗРАЧНОСТЬ");
        note.addView(txt("Локальное распознавание запускается только после импорта ONNX и предоставления разрешения MediaProjection. HUD отображает прямоугольники; автоматического наведения, стрельбы или инъекции жестов здесь нет. Некоторые приложения могут запретить захват экрана.",13,MUTED,false));
    }
    private void switchTab(int which){tab=which;showScreen();}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void requestOverlay(){if(Settings.canDrawOverlays(this)){toast("Разрешение уже есть");return;}
        Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}
    private void requestCapture(){
        MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(),CAPTURE_REQUEST);
    }
    private void pickMusic(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,TRACK_REQUEST);}
    private void pickModel(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,MODEL_REQUEST);}
    private void commandMusic(String action){
        if(MusicService.PLAY.equals(action) && getSharedPreferences("settings",MODE_PRIVATE).getString("musicUri",null)==null){toast("Сначала выбери MP3");return;}
        Intent i=new Intent(this,MusicService.class).setAction(action);
        try{if(MusicService.PLAY.equals(action)){
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
            }else{startService(i);}
            ui.postDelayed(this::showScreen,300);
        }catch(Exception e){toast("Ошибка аудио: "+e.getMessage());}
    }
    private boolean modelSaved(){return getFilesDirFile().exists();}
    private File getFilesDirFile(){return new File(getFilesDir(),"imported_model.dat");}
    private String shorten(String s,int max){return s.length()>max?s.substring(0,max-2)+"…":s;}
    private String fileName(Uri uri){
        String name="audio";Cursor c=null;
        try{c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst())name=c.getString(0);
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return name==null?"file":name;
    }
    @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);
        if(code!=RESULT_OK||data==null){if(req==CAPTURE_REQUEST)toast("Захват отменён");return;}
        if(req==CAPTURE_REQUEST){
            Intent i=new Intent(this,VisionService.class).setAction(VisionService.ACTION_START);
            i.putExtra(VisionService.EXTRA_RESULT_CODE,code);i.putExtra(VisionService.EXTRA_RESULT_DATA,data);
            try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);toast("Захват запущен");ui.postDelayed(this::showScreen,650);}
            catch(Exception e){toast("Не удалось начать захват: "+e.getMessage());}
        }else if(req==TRACK_REQUEST){
            Uri uri=data.getData();if(uri==null)return;
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
            commandMusic(MusicService.STOP);
            getSharedPreferences("settings",MODE_PRIVATE).edit().putString("musicUri",uri.toString()).putString("musicName",fileName(uri)).apply();
            toast("Музыка выбрана. Нажми ▶");showScreen();
        }else if(req==MODEL_REQUEST){
            Uri uri=data.getData();if(uri==null)return;
            String name=fileName(uri);String lowercase=name.toLowerCase(Locale.US);
            if(!lowercase.endsWith(".onnx")){toast("Нужен именно файл .onnx из архива обученных весов");return;}
            if(VisionStatus.capturing){toast("Сначала останови захват");return;}
            toast("Сохраняю модель...");
            new Thread(()->{
                try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(getFilesDirFile())){
                    if(in==null)throw new IllegalStateException("Нельзя открыть файл");byte[] buf=new byte[32768];int read;long bytes=0;
                    while((read=in.read(buf))!=-1){bytes+=read;if(bytes>200L*1024*1024)throw new IllegalArgumentException("Максимум 200 МБ");out.write(buf,0,read);}
                    if(bytes<1024)throw new IllegalArgumentException("Пустой файл модели");
                    getSharedPreferences("settings",MODE_PRIVATE).edit().putString("modelName",name).apply();
                    runOnUiThread(()->{toast("ONNX сохранён. Перейди в Захват и нажми Начать");showScreen();});
                }catch(Exception e){getFilesDirFile().delete();runOnUiThread(()->toast("Не удалось импортировать: "+e.getMessage()));}
            },"vanta-model-import").start();
        }
    }
}
