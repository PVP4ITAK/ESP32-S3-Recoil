package ru.vanta.vision;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/** Display-only touch-through HUD; no automated aiming, touches or input injection. */
public final class HudService extends Service {
    public static final String ACTION_HIDE = "ru.vanta.vision.HUD_HIDE";
    private WindowManager wm;
    private HudView overlay;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable redraw=new Runnable(){@Override public void run(){
        if(overlay!=null){overlay.invalidate();ui.postDelayed(this,250);}
    }};
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_HIDE.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(overlay!=null)return START_STICKY;
        try {
            wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            overlay=new HudView();
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP | Gravity.LEFT;
            lp.alpha=.70f;
            wm.addView(overlay,lp);
            VisionStatus.hudVisible=true;
            ui.post(redraw);
        }catch(Exception ex){VisionStatus.error="HUD: "+ex.getMessage();stopSelf();}
        return START_STICKY;
    }
    @Override public void onDestroy(){
        ui.removeCallbacks(redraw);
        if(wm!=null && overlay!=null)try{wm.removeView(overlay);}catch(Exception ignored){}
        overlay=null;VisionStatus.hudVisible=false;super.onDestroy();
    }
    private final class HudView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        HudView(){super(HudService.this);setWillNotDraw(false);}
        @Override protected void onDraw(Canvas c){
            float d=getResources().getDisplayMetrics().density;
            p.setColor(0xCC27E6D4);p.setStrokeWidth(2*d);p.setStyle(Paint.Style.FILL);
            p.setTypeface(android.graphics.Typeface.create("monospace",1));p.setTextSize(12*d);
            c.drawText("VANTA // "+(VisionStatus.modelReady?"HEAD+BODY":"DEMO"),16*d,40*d,p);
            p.setTextSize(10*d);
            c.drawText(VisionStatus.modelReady?
                (VisionStatus.detections.length+" BOXES // "+VisionStatus.inferenceMs+"ms"):
                "MODEL NOT LOADED",16*d,56*d,p);
            if(!VisionStatus.modelReady || !VisionStatus.capturing)return;
            VisionStatus.Detection[] detections=VisionStatus.detections;
            for(VisionStatus.Detection box:detections){
                int color=box.kind==1?0xFFE65FFA:0xFF27E6D4;
                float l=box.left*getWidth(), t=box.top*getHeight();
                float r=box.right*getWidth(), b=box.bottom*getHeight();
                p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.7f*d);
                c.drawRect(l,t,r,b,p);
                p.setStyle(Paint.Style.FILL);p.setTextSize(10*d);
                String title=(box.kind==1?"HEAD ":"BODY ")+Math.round(box.score*100)+"%";
                float ty=Math.max(72*d,t-6*d);
                c.drawText(title,l,ty,p);
            }
        }
    }
}
