package ru.vanta.vision;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/** Display-only touch-through HUD. No aiming or synthetic touch events. */
public final class HudService extends Service {
    public static final String ACTION_HIDE = "ru.vanta.vision.HUD_HIDE";
    private WindowManager wm;
    private HudView overlay;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable redraw=new Runnable(){@Override public void run(){
        if(overlay==null)return;
        overlay.invalidate();
        // Smooth visual updates independent from ONNX inference cadence.
        ui.postDelayed(this, VisionStatus.capturing && VisionStatus.modelReady ? 33L : 180L);
    }};
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_HIDE.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(overlay!=null)return START_STICKY;
        try {
            wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            overlay=new HudView();
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                // Keep the overlay out of MediaProjection to avoid feeding drawn boxes
                // back into the detector (supported behavior is device-dependent).
                WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP | Gravity.LEFT;
            lp.alpha=.70f;
            wm.addView(overlay,lp);
            VisionStatus.hudVisible=true;
            ui.post(redraw);
        }catch(Exception ex){VisionStatus.error="HUD: "+ex.getMessage();stopSelf();}
        return START_STICKY;
    }
    @Override public void onDestroy(){
        ui.removeCallbacks(redraw);
        if(wm!=null && overlay!=null)try{wm.removeView(overlay);}catch(Exception ignored){}
        overlay=null;VisionStatus.hudVisible=false;super.onDestroy();
    }
    private final class HudView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final SmoothTracker tracker=new SmoothTracker();
        private long lastSequence=-1;
        private long lastCaptureRevision=-1;
        private final float density;
        HudView(){super(HudService.this);setWillNotDraw(false);density=getResources().getDisplayMetrics().density;}
        @Override protected void onDraw(Canvas c){
            long now=SystemClock.elapsedRealtime();
            if(!VisionStatus.capturing || lastCaptureRevision!=VisionStatus.captureRevision){
                tracker.reset(); lastSequence=-1;
                lastCaptureRevision=VisionStatus.captureRevision;
            }
            if(VisionStatus.capturing && VisionStatus.modelReady && lastSequence!=VisionStatus.inferenceCount){
                // Detections are published before the volatile inferenceCount increases.
                lastSequence=VisionStatus.inferenceCount;
                tracker.accept(VisionStatus.detections,now);
            }
            tracker.advance(now);
            p.setColor(0xCC27E6D4);p.setStrokeWidth(2*density);p.setStyle(Paint.Style.FILL);
            p.setTypeface(android.graphics.Typeface.create("monospace",1));p.setTextSize(12*density);
            c.drawText("VANTA // "+(VisionStatus.modelReady?"HEAD+BODY":"DEMO"),16*density,40*density,p);
            p.setTextSize(10*density);
            c.drawText(VisionStatus.modelReady?
                ("MODEL "+VisionStatus.neuralMs+"ms / PRE "+VisionStatus.preprocessMs+"ms / "+VisionStatus.inferenceEngine):
                "MODEL NOT LOADED",16*density,56*density,p);
            if(!VisionStatus.modelReady || !VisionStatus.capturing)return;
            for(SmoothTracker.Track box:tracker.getTracks()){
                float opacity=box.opacity(now);
                if(opacity<=0f)continue;
                int color=box.kind==1?0xFFE65FFA:0xFF27E6D4;
                p.setColor(color);
                p.setAlpha(Math.round(255*opacity));
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.7f*density);
                float l=box.left()*getWidth(), t=box.top()*getHeight();
                float r=box.right()*getWidth(), b=box.bottom()*getHeight();
                c.drawRect(l,t,r,b,p);
                p.setStyle(Paint.Style.FILL);p.setTextSize(10*density);
                String title=(box.kind==1?"HEAD ":"BODY ")+Math.round(box.score*100)+"%";
                c.drawText(title,l,Math.max(72*density,t-6*density),p);
            }
            p.setAlpha(255);
        }
    }
}
